# Resistor Lens v7 — conspicuous low-confidence warning + regression suite

Native macOS 14+ menu-bar resistor-reader prototype. **Version 7 keeps the actual
color detection/classification algorithm from v5 byte-for-byte unchanged**.
The new work is a reproducible test suite, offline labeled-photo import pipeline,
and a clearer confidence-review summary in the results window.

> **Accuracy caveat:** On-screen confidence percentages are heuristic classifier
> scores (10–98%), **not measured probabilities**. The real-photo test suite has
> not been run here. Always confirm a resistor's value with a multimeter when
> correctness matters.

## What changed in v7

- A conspicuous **yellow, black-bordered, bold-black-text** banner appears directly below
  the result window heading with **WARNING: LOW CONFIDENCE** when either the
  **average confidence is below 60%** or **any single unedited band is below 25%**.
  An active band with no detector score also raises the warning. Conditions
  use strict *below* comparisons; scores exactly 60% or 25% do not trip
  their respective conditions.
- The banner **names which limit failed**, displays the actual average and/or
  low-scoring band numbers, and recommends checking the source magnifier and
  correcting the band menu. It updates immediately as bands are edited, the
  count changes, or warning thresholds are adjusted in **Settings → Feedback and speech**.
- **Average** means the arithmetic mean of scored, *unmodified* active bands.
  Manual overrides are excluded rather than being assigned imaginary 100%
  detector confidence. Bands with no score trigger their own warning instead
  of silently lowering the mean with an invented zero. A fully manual reading
  has no remaining detector confidence to assess; no banner is shown, but
  the per-band labels still say "Manual override".
- Yellow banner settings default to 60% average and 25% individual; independently
  adjustable within 40–85% and 10–50%. The older per-band 75% review hints
  are separate and unchanged.
- Added portable `ConfidenceWarning.swift` and `ConfidenceWarningTests.swift` with
  tests of both triggers, boundary equality, missing values, manual correction,
  adjustable thresholds, 4/5/6 band counts and explanation text.
- The actual scanning algorithm remains **byte-for-byte unchanged from v5/v6**.

## What changed in v6

- **No external GitHub scanning algorithm adopted.** `ResistorLens/ColorBandDetector.swift`
  is identical to v5 (SHA-256: `732b2554a5d5fcbb96e96d7669ebf85afc795c22e8bba6794a91f71fa7e0be89`).
- **50 deterministic synthetic RGB scans** in `Fixtures/synthetic_scans_50.json`, generated
  by `Tools/generate_synthetic_corpus.py`. They cover **all 12 colors**, **4/5/6 bands**, and
  **10 image variations** (including darkening, brightening, reduced saturation, warming,
  cooling, grain, simulated glare, faded colors, and body-color changes).
- **Source-annotated photograph importer** in `Tools/import_roboflow_yolo.py`. Download
  licensed labeled images yourself, then extract **exactly 50 RGB scan profiles** without
  including the original photographs in the result. The tool records source URL,
  license, relative filename and image SHA-256 for auditing.
- **macOS end-to-end detector test runner** in `Tests/DetectorCorpusTests.swift`.
  It reconstructs image pixels from RGB scan data, invokes the **production**
  `ColorBandDetector.detect` implementation, and reports overall accuracy,
  per-color match rates and measured correctness in score buckets **10–49%,
  50–74%, 75–89%, 90–98%**.
- **Version 6 result-window review summary**, showing bands below the user's
  warning threshold and manual corrections. Existing confidence percentages,
  editable color menus, magnifier and accessibility features remain.

This release does **not** implement the previously discussed optional multi-shade
matching, body subtraction, parallel scanning, denoising, or statistical score
calibration. Those would change the production detector and should be evaluated
against a labeled photographic baseline before being enabled. The emphasis here
is on keeping the current detector and **measuring it first**.

## Obtain real-world test images (50 photos, not included)

A source suitable for extraction is:

**Roboflow — Resistor Band Dataset** (193 images advertised, 12 painted-band
colors, CC BY 4.0):
https://universe.roboflow.com/my-training-vnq4n/resistor-band-v4ryy

Another candidate is the **Public Domain Resistor Color Band Detection** dataset
(134 images, 11 band classes; no silver in the published class list):
https://universe.roboflow.com/image-gpmgb/resistor-color-band-detection-fnbak

To create **50 source-derived test scans**:

1. Open the first dataset's page and download an **object-detection YOLOv8**
   export containing `data.yaml`, `train/valid/test/images` and corresponding
   `labels` directories. Download availability/format may depend on Roboflow's UI,
   account, and dataset version.
2. Unzip it to a directory on your Mac.
3. With Python 3 and the dependencies installed, from this project directory:

   ```sh
   python3 -m pip install pillow pyyaml
   python3 Tools/import_roboflow_yolo.py /path/to/downloaded-dataset \
     --source-url https://universe.roboflow.com/my-training-vnq4n/resistor-band-v4ryy \
     --license 'CC BY 4.0'
   ```

4. The importer requires **50 distinct image files** with **4–6 valid painted-band
   annotations** in a single band sequence. It excludes ambiguous or incomplete
   annotation sets. If fewer than 50 qualify, it stops without producing
   a misleading file. Additional images or human annotation may be needed.
5. The output is `Fixtures/real_scans_50.json`. It stores only **360 RGB triplets
   per image**, known annotated band colors, expected resistance/tolerance,
   provenance and SHA-256 hash; no JPEG/PNG files are copied into the project.
   Third-party labels may be mistaken; visually verify labels for a trustworthy
   accuracy study.
6. Run the macOS detector suite as shown below. The audited accuracy and
   confidence buckets then come from actual observed detector outcomes rather
   than invented percentages.

**Important:** The real-image JSON is *not included* in this v6 archive because
50 web image files could not be downloaded and verified in this environment.
The **included 50 cases are synthetic only**, explicitly marked as such.

## Run tests

From the unzipped `ResistorLens_v6` project directory:

```sh
./Tests/run_all.sh
```

On **Linux**, the decoder, menus, window geometry, shortcut, synthetic corpus
validation and confidence audit accounting tests run. The production image
scan is skipped because `AppKit` does not exist on Linux.

On **macOS**, the same script additionally compiles `ColorBandDetector.swift`
with AppKit and runs the actual production detector against the 50 synthetic
pixel scans; it writes `synthetic_detector_report.csv` to the project root.
When `Fixtures/real_scans_50.json` exists, it also tests those **50 source
annotated photographs** and writes `real_photo_detector_report.csv`.

The final report includes:
- Exact entire-band-sequence match count (e.g., `x/50`, not a claimed result).
- Position-matched band accuracy and missing/extra bands.
- Correct-versus-total by reference pigment.
- Counts, empirical correctness and mean *heuristic score* in 4 confidence buckets.

The test report is diagnostic rather than a fictitious pass guarantee: images
with degraded colors may fail. This is precisely what a baseline test should
reveal. Use a labeled **holdout** test split for an unbiased study whenever
possible, and avoid calibrating to the same images used to adjust the scanner.

## Run the app

1. Open `ResistorLens.xcodeproj` in Xcode 15.2+ on macOS 14+.
2. Run **My Mac** with **⌘R**. Allow Screen Recording permission if prompted.
3. Press **⇧⌥R** by default, draw a line from the first to last resistor band.
4. Review the cropped source image, generated resistor and per-band estimates.
5. Use the color dropdowns for correction and press **Esc** to close.
6. **⌘,** opens Settings while Resistor Lens is active. v5 login, voice, rate,
   window position and future-hover sensitivity settings are retained.

Launch at Login requires proper macOS signing and a stably installed `.app`, as
explained in the v5 documentation. The sensitivity setting is still a placeholder
for a future automatic-hover detector, **not an active detection control**.

## Test-file guide

- `Fixtures/synthetic_scans_50.json` — 50 **synthetic**, deterministic 360-sample RGB profiles.
- `Tools/generate_synthetic_corpus.py` — regenerate the 50 synthetic profiles.
- `Tools/import_roboflow_yolo.py` — convert 50 externally downloaded annotated photos into pixel profiles.
- `Tests/CorpusFormat.swift` — validates profile dimensions, colors and expected readings.
- `Tests/CorpusIntegrityTests.swift` — 50-case coverage and confidence bucket accounting tests.
- `Tests/ConfidenceAudit.swift` — actual correctness/score audit, including by-color breakdown.
- `Tests/DetectorCorpusTests.swift` — macOS black-box test of the **unchanged** production detector.
- `Tests/run_all.sh` — portable test command and macOS-specific detector run.

## Security, licensing and validation

Everything runs locally. No captured screen images or extracted photo data are
uploaded automatically. The importer's `source` and `license` strings are
provided by the person downloading the data; they should be checked before
redistribution. If redistributing any CC BY 4.0 derived data, retain attribution
and review the original terms. The synthetic set was created specifically for
this project.

**Verified here:** All portable Swift tests passed; 50 synthetic profiles pass
corpus/decoder validation; the importer was exercised against 50 temporary
locally generated annotated *test* images; all Swift files passed syntax parsing.

**Not verified here:** The full Xcode application build and real macOS window
behavior, the actual production detector results on synthetic scans, or any
real-photo accuracy percentage. Those require macOS and downloaded labeled
photographs.
