#!/usr/bin/env python3
"""Convert up to 50 *locally downloaded*, labeled Roboflow YOLO photos into
360-sample RGB profiles. Stores no photos in the output. Does not scrape.

Usage:
  python3 -m pip install pillow pyyaml
  python3 Tools/import_roboflow_yolo.py /path/to/unzipped-yolov8-dataset \
      --source-url https://universe.roboflow.com/my-training-vnq4n/resistor-band-v4ryy \
      --license 'CC BY 4.0'

Only accepts images with 4-6 individually annotated, recognizable bands whose
sequence decodes to a valid reading. Other cases are skipped and reported.
Color labels are *dataset annotations*, not independent electrical measurements.
"""
import argparse
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

try:
    import yaml
    from PIL import Image, ImageOps
except ImportError as ex:
    raise SystemExit('Install dependencies: python3 -m pip install pillow pyyaml') from ex

DIGIT=dict(zip('Black Brown Red Orange Yellow Green Blue Violet Gray White'.split(),range(10)))
MULT={'Black':1,'Brown':10,'Red':100,'Orange':1000,'Yellow':1e4,
      'Green':1e5,'Blue':1e6,'Violet':1e7,'Gray':1e8,'White':1e9,
      'Gold':0.1,'Silver':0.01}
TOL={'Brown':1,'Red':2,'Green':0.5,'Blue':0.25,'Violet':0.1,
     'Gray':0.05,'Gold':5,'Silver':10}
PPM={'Black':250,'Brown':100,'Red':50,'Orange':15,'Yellow':25,
     'Green':20,'Blue':10,'Violet':5,'Gray':1}

CANONICAL={k.lower():k for k in ('Black Brown Red Orange Yellow Green Blue Violet Gray White Gold Silver').split()}
CANONICAL.update({'grey':'Gray', 'purple':'Violet'})


def lookup_label(raw):
    key = ''.join(ch for ch in raw.lower().strip() if ch.isalpha())
    return CANONICAL.get(key)


def read_names(dataset):
    candidates=list(dataset.glob('data.yaml'))+list(dataset.glob('data.yml'))
    if not candidates: raise ValueError('No data.yaml in dataset root')
    raw=yaml.safe_load(candidates[0].read_text())['names']
    if isinstance(raw,list): return {i:lookup_label(v) for i,v in enumerate(raw)}
    return {int(k):lookup_label(v) for k,v in raw.items()}


def decode(colors):
    n=len(colors)
    if not 4<=n<=6: return None
    digits=2 if n==4 else 3
    try:
        if any(x not in DIGIT for x in colors[:digits]): return None
        integer=int(''.join(str(DIGIT[x]) for x in colors[:digits]))
        if integer < (10 if digits==2 else 100): return None
        multiplier=MULT[colors[digits]]
        tolerance=TOL[colors[digits+1]]
        ppm=PPM[colors[5]] if n==6 else None
        return (integer*multiplier,tolerance,ppm)
    except KeyError:
        return None


def scan_pixels(image, a, b):
    im=ImageOps.exif_transpose(image).convert('RGB')
    w,h=im.size
    start=(a['x']*w,a['y']*h)
    end=(b['x']*w,b['y']*h)
    dx,dy=end[0]-start[0],end[1]-start[1]
    length=max(1,math.hypot(dx,dy))
    nx,ny=-dy/length,dx/length
    def pixel(x,y):
        return im.getpixel((min(w-1,max(0,round(x))),min(h-1,max(0,round(y)))))
    profile=[]
    for i in range(360):
        t=i/359
        x,y=start[0]+dx*t,start[1]+dy*t
        samples=[pixel(x+delta*nx,y+delta*ny) for delta in range(-2,3)]
        profile.append([round(sum(s[channel] for s in samples)/len(samples)) for channel in range(3)])
    return profile


def candidate(label_path,names):
    boxes=[]
    for line in label_path.read_text().splitlines():
        parts=line.split()
        if len(parts)!=5: return None
        try:
            category=int(float(parts[0]))
            x,y,bw,bh=map(float,parts[1:])
        except ValueError: return None
        color=names.get(category)
        if color is None: return None
        if not (0<=x<=1 and 0<=y<=1 and 0<bw<=1 and 0<bh<=1): return None
        boxes.append(dict(x=x,y=y,color=color))
    if len(boxes) not in (4,5,6): return None
    xs=[b['x'] for b in boxes]
    ys=[b['y'] for b in boxes]
    axis='x' if max(xs)-min(xs)>=max(ys)-min(ys) else 'y'
    boxes.sort(key=lambda b:b[axis])
    # Gold/Silver tolerance should conventionally end the sequence. Orientation
    # ambiguity is deliberately skipped rather than silently assigned a value.
    if boxes[0]['color'] in ('Gold','Silver') and boxes[-1]['color'] not in ('Gold','Silver'):
        boxes.reverse()
    colors=[b['color'] for b in boxes]
    parsed=decode(colors)
    if parsed is None: return None
    # A very small span suggests these boxes are not meaningful painted bands.
    dist=math.hypot(boxes[-1]['x']-boxes[0]['x'],boxes[-1]['y']-boxes[0]['y'])
    if dist<0.09: return None
    return boxes,colors,parsed


def image_for_label(label, root):
    # Standard Roboflow export: split/labels/a.txt -> split/images/a.jpg
    directory=label.parent.parent/'images'
    for suffix in ('.jpg','.jpeg','.png','.webp','.bmp','.JPG','.PNG'):
        found=directory/(label.stem+suffix)
        if found.exists(): return found
    return None


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('dataset',type=Path,help='unzipped Roboflow YOLOv8 export directory')
    ap.add_argument('--source-url',required=True, help='public source page URL for attribution')
    ap.add_argument('--license',required=True, help='e.g. CC BY 4.0')
    ap.add_argument('--limit',type=int,default=50)
    ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'Fixtures'/'real_scans_50.json')
    args=ap.parse_args()
    if args.limit != 50: raise SystemExit('This suite expects exactly 50 examples; use --limit 50')
    root=args.dataset.resolve()
    names=read_names(root)
    labels=[]
    # Prefer hold-out/test images. Fall back to valid/train only to reach 50;
    # report splits so the user knows they are not all independent test data.
    for split in ('test','valid','val','train'):
        location=root/split/'labels'
        if location.is_dir(): labels.extend(sorted(location.glob('*.txt')))
    counts=Counter()
    cases=[]
    for label in labels:
        if len(cases)>=args.limit: break
        chosen=candidate(label,names)
        if chosen is None:
            counts['invalid_or_ambiguous_annotations']+=1
            continue
        image_path=image_for_label(label,root)
        if image_path is None:
            counts['missing_image']+=1
            continue
        boxes,colors,parsed=chosen
        try:
            raw=image_path.read_bytes()
            with Image.open(image_path) as photo:
                pixels=scan_pixels(photo,boxes[0],boxes[-1])
        except Exception as ex:
            counts['image_read_error']+=1
            print('Skip',image_path.name,ex)
            continue
        cases.append({
          'id':f'real-{len(cases)+1:03d}', 'kind':'source-annotated-photograph',
          'source':args.source_url,'license':args.license,
          'originFile':str(image_path.relative_to(root)),
          'imageSHA256':hashlib.sha256(raw).hexdigest(),
          'bands':colors,'expectedOhms':parsed[0],
          'expectedTolerancePercent':parsed[1], 'expectedPPM':parsed[2],
          'rgbScan':pixels,
        })
        counts['accepted']+=1
    if len(cases)<50:
        raise SystemExit(f'Only {len(cases)} usable annotated photographs; need 50. Skips: {dict(counts)}. No output written.')
    result={'schemaVersion':1,'datasetType':'Roboflow annotated photograph RGB scans',
      'sourceDataset':args.source_url,'license':args.license,
      'warning':'Extracted RGB pixels from 50 distinct annotated photographs. Original photographs are NOT bundled. Labels are third-party annotations and should be verified before claiming accuracy.',
      'cases':cases}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=1)+'\n')
    print('Wrote',len(cases),'real-image RGB profiles to',args.output)
    print('Split distribution',dict(Counter(x['originFile'].split('/')[0] for x in cases)))
    print('Skips',dict(counts))

if __name__=='__main__': main()
