#!/usr/bin/env python3
"""Generate 50 deterministic, synthetic RGB profiles for black-box v5/v6 detector tests.
No external photos are used or implied. These are synthetic pixels, not real-world
confidence calibration data. Run from any directory, Python 3.9+ stdlib only.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'Fixtures' / 'synthetic_scans_50.json'
RGB = {
    'Black': [23,23,23], 'Brown':[105,54,26], 'Red':[210,35,38],
    'Orange':[244,112,18], 'Yellow':[245,210,39], 'Green':[30,141,59],
    'Blue':[29,77,202], 'Violet':[140,61,182], 'Gray':[129,129,129],
    'White':[242,242,242], 'Gold':[199,154,50], 'Silver':[189,191,196]
}
BODIES = {'tan':[221,184,142], 'blue':[145,180,199], 'green':[163,198,156],
          'cream':[234,216,186], 'rose':[207,165,156]}

# All 12 pigment colors represented, with 4, 5 and 6-band arrangements.
S = [
 'Yellow Violet Red Gold', 'Brown Black Red Gold', 'Red Red Brown Gold',
 'Orange Orange Brown Gold', 'Green Blue Brown Gold', 'Blue Gray Red Gold',
 'Violet Green Orange Gold', 'Gray Red Black Gold', 'White Brown Brown Gold',
 'Brown Black Gold Silver', 'Brown Black Silver Gold', 'Red Black Gold Brown',
 'Yellow Violet Gold Silver', 'Green Blue Silver Gold', 'Orange Orange Black Brown',
 'Brown Red Yellow Silver', 'White Black Green Gold', 'Violet Gray Blue Red',
 'Blue White Black Violet', 'Brown Red Brown Green',
 'Brown Black Black Brown Brown', 'Red Violet Orange Black Brown',
 'Orange Orange Black Red Brown', 'Yellow Violet Black Brown Red',
 'Green Blue Black Red Green', 'Blue Gray Black Orange Blue',
 'Violet Green Black Yellow Violet', 'Gray Red Black Brown Gray',
 'White Brown Black Gold Gold', 'Brown Black Black Silver Silver',
 'Red Black Black Gold Brown', 'Yellow Violet Black Silver Brown',
 'Green Blue Black Black Green', 'Orange Orange Black Brown Gold',
 'Brown Red Black Red Silver', 'White Black Black Yellow Gold',
 'Violet Gray Black Green Red', 'Blue White Black Violet Brown',
 'Brown Red Black Brown Violet', 'Gray White Black Gold Blue',
 'Brown Black Black Brown Brown Brown', 'Red Violet Orange Black Brown Red',
 'Orange Orange Black Red Brown Orange', 'Yellow Violet Black Brown Red Yellow',
 'Green Blue Black Red Green Green', 'Blue Gray Black Orange Blue Blue',
 'Violet Green Black Yellow Violet Violet', 'Gray Red Black Brown Gray Gray',
 'White Brown Black Gold Gold Brown', 'Brown Black Black Silver Silver Blue'
]
assert len(S)==50
MULT={'Black':1,'Brown':10,'Red':100,'Orange':1000,'Yellow':1e4,
      'Green':1e5,'Blue':1e6,'Violet':1e7,'Gray':1e8,'White':1e9,
      'Gold':0.1,'Silver':0.01}
DIGIT=dict(zip('Black Brown Red Orange Yellow Green Blue Violet Gray White'.split(),range(10)))
TOL={'Brown':1,'Red':2,'Green':0.5,'Blue':0.25,'Violet':0.1,'Gray':0.05,'Gold':5,'Silver':10}
PPM={'Black':250,'Brown':100,'Red':50,'Orange':15,'Yellow':25,'Green':20,'Blue':10,'Violet':5,'Gray':1}
MODES=['nominal','dim','bright','low_saturation','warm','cool','grain','glare','faded','dark_body']


def clamp(x): return int(max(0,min(255,round(x))))


def modify(rgb,mode,seed,pos):
    r,g,b=rgb
    if mode=='dim':
        return [clamp(c*.68) for c in rgb]
    if mode=='bright':
        return [clamp(c*.75+55) for c in rgb]
    if mode=='low_saturation':
        v=.2126*r+.7152*g+.0722*b
        return [clamp(c*.55+v*.45) for c in rgb]
    if mode=='warm':
        return [clamp(r*1.07+10),clamp(g*1.01),clamp(b*.89)]
    if mode=='cool':
        return [clamp(r*.91),clamp(g*1.0),clamp(b*1.08+8)]
    if mode=='grain':
        noise=((pos*37+seed*53)%19)-9
        return [clamp(c+noise) for c in rgb]
    if mode=='glare':
        shine=22 if 155<pos<180 else 0
        return [clamp(c+shine) for c in rgb]
    if mode=='faded':
        return [clamp(c*.8+37) for c in rgb]
    if mode=='dark_body':
        return [clamp(c*.88) for c in rgb]
    return rgb[:]


def build(i,colors):
    mode=MODES[i%len(MODES)]
    bodykind=list(BODIES)[i%len(BODIES)]
    body=BODIES[bodykind][:]
    if mode=='dark_body': body=[clamp(c*.63) for c in body]
    # Pixel 0 and 359 are band centers: exactly what the user selects.
    centers={4:[0,99,209,359],5:[0,71,151,235,359],6:[0,58,116,176,272,359]}[len(colors)]
    width=360
    pixels=[]
    for x in range(width):
        matched=[j for j,center in enumerate(centers) if abs(x-center)<=11]
        actual=RGB[colors[matched[0]]] if matched else body
        pixels.append(modify(actual,mode,i,x))
    digits=2 if len(colors)==4 else 3
    value=0
    for c in colors[:digits]: value=value*10+DIGIT[c]
    value*=MULT[colors[digits]]
    return {
       'id':f'synthetic-{i+1:03d}', 'kind':'synthetic', 'source':'generated; not a web photo',
       'bands':colors,'expectedOhms':value,'expectedTolerancePercent':TOL[colors[digits+1]],
       'expectedPPM':PPM[colors[5]] if len(colors)==6 else None,
       'style':mode,'body':bodykind, 'rgbScan':pixels
    }

cases=[build(i,entry.split()) for i,entry in enumerate(S)]
assert all(4<=len(c['bands'])<=6 for c in cases)
assert set.union(*(set(c['bands']) for c in cases))==set(RGB)
OUT.write_text(json.dumps({'schemaVersion':1,'datasetType':'synthetic RGB scans',
   'warning':'These are programmatically created pixels, NOT samples from 50 web images. Confidence percentages obtained from them cannot calibrate accuracy on real photographs.',
   'scanSampling':'360 sRGB samples, in left-to-right band-center order',
   'cases':cases},indent=1)+'\n')
print('Created',OUT, 'with',len(cases),'synthetic tests')
