import Foundation

/// Deterministic coordinate conversion for the source-image magnifier.
/// Kept separate from AppKit so it can be tested with command-line Swift.
struct CropGeometry {
    let midpointInPixels: CGPoint
    let rotationRadians: CGFloat
    let outputScale: CGFloat
    let outputWidth: Int
    let outputHeight: Int
    let scanStartX: CGFloat
    let scanEndX: CGFloat

    static func calculate(imagePixelSize: CGSize, screenFrame: CGRect,
                          from start: CGPoint, to end: CGPoint) -> CropGeometry? {
        guard imagePixelSize.width > 0, imagePixelSize.height > 0,
              screenFrame.width > 0, screenFrame.height > 0 else { return nil }
        let pxPerPointX = imagePixelSize.width / screenFrame.width
        let pxPerPointY = imagePixelSize.height / screenFrame.height
        let p0 = CGPoint(x: (start.x - screenFrame.minX) * pxPerPointX,
                         y: (start.y - screenFrame.minY) * pxPerPointY)
        let p1 = CGPoint(x: (end.x - screenFrame.minX) * pxPerPointX,
                         y: (end.y - screenFrame.minY) * pxPerPointY)
        let dx = p1.x - p0.x
        let dy = p1.y - p0.y
        let axisLength = hypot(dx, dy)
        guard axisLength >= 12, axisLength.isFinite else { return nil }

        let nativeWidth = max(110.0, axisLength * 1.50)
        let nativeHeight = max(76.0, axisLength * 0.55)
        let outputScale = min(1.0, 1100.0 / nativeWidth, 460.0 / nativeHeight)
        let outputWidth = max(1, Int((nativeWidth * outputScale).rounded()))
        let outputHeight = max(1, Int((nativeHeight * outputScale).rounded()))
        let lineFraction = min(1.0, axisLength * outputScale / CGFloat(outputWidth))

        return CropGeometry(midpointInPixels: CGPoint(x: (p0.x + p1.x) / 2,
                                                       y: (p0.y + p1.y) / 2),
                            rotationRadians: atan2(dy, dx),
                            outputScale: outputScale,
                            outputWidth: outputWidth,
                            outputHeight: outputHeight,
                            scanStartX: (1 - lineFraction) / 2,
                            scanEndX: (1 + lineFraction) / 2)
    }
}
