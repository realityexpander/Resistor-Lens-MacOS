import Foundation
import Combine
import ServiceManagement
import AVFoundation

/// Small, entirely local, immediately saved preferences model.
final class AppSettings: ObservableObject {
    private enum Key {
        static let shortcutCode = "activationShortcut.keyCode"
        static let shortcutModifiers = "activationShortcut.modifiers"
        static let highContrast = "highContrastBandEdges"
        static let preferredBandCount = "preferredBandCount"
        static let defaultZoom = "defaultCropZoom"
        static let scanLine = "defaultShowScanLine"
        static let sharpPixels = "defaultSharpPixels"
        static let autoSpeak = "autoSpeakAfterDetection"
        static let warningThreshold = "lowConfidenceWarningThreshold"
        static let averageWarningThreshold = "averageConfidenceBannerThreshold"
        static let criticalBandThreshold = "criticalBandBannerThreshold"
        static let rememberWindow = "rememberResultWindowFrame"
        static let speechRate = "speechRate"
        static let speechVoice = "speechVoiceIdentifier"
        static let hoverSensitivity = "futureHoverSensitivity"
    }

    private let defaults: UserDefaults

    // Read from macOS, not UserDefaults: Login Items can be changed in System Settings.
    @Published private(set) var launchAtLoginEnabled = false
    @Published private(set) var loginItemMessage: String? = nil

    @Published private(set) var activationShortcut: ShortcutSpec
    /// Live UI status only: this is not stored as a preference.
    @Published var shortcutAvailable = true
    @Published var preferredBandCount: Int {
        didSet { defaults.set(preferredBandCount, forKey: Key.preferredBandCount) }
    }
    @Published var highContrastEdges: Bool {
        didSet { defaults.set(highContrastEdges, forKey: Key.highContrast) }
    }
    @Published var defaultZoom: Double {
        didSet { defaults.set(defaultZoom, forKey: Key.defaultZoom) }
    }
    @Published var showScanLine: Bool {
        didSet { defaults.set(showScanLine, forKey: Key.scanLine) }
    }
    @Published var sharpPixels: Bool {
        didSet { defaults.set(sharpPixels, forKey: Key.sharpPixels) }
    }
    @Published var automaticallySpeak: Bool {
        didSet { defaults.set(automaticallySpeak, forKey: Key.autoSpeak) }
    }
    @Published var warningThreshold: Int {
        didSet { defaults.set(warningThreshold, forKey: Key.warningThreshold) }
    }

    /// Banner thresholds, deliberately separate from the existing per-band review hints.
    @Published var averageWarningThreshold: Int {
        didSet { defaults.set(averageWarningThreshold, forKey: Key.averageWarningThreshold) }
    }
    @Published var criticalBandThreshold: Int {
        didSet { defaults.set(criticalBandThreshold, forKey: Key.criticalBandThreshold) }
    }

    @Published var rememberResultWindow: Bool {
        didSet { defaults.set(rememberResultWindow, forKey: Key.rememberWindow) }
    }
    @Published var speechRate: Double {
        didSet { defaults.set(speechRate, forKey: Key.speechRate) }
    }
    @Published var speechVoiceIdentifier: String {
        didSet { defaults.set(speechVoiceIdentifier, forKey: Key.speechVoice) }
    }
    /// Reserved for a subsequent automatic cursor-hover detector. The current
    /// draw-a-line algorithm deliberately does not use this value.
    @Published var hoverSensitivity: Int {
        didSet { defaults.set(hoverSensitivity, forKey: Key.hoverSensitivity) }
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        let code = defaults.object(forKey: Key.shortcutCode) as? Int
        let bits = defaults.object(forKey: Key.shortcutModifiers) as? Int
        let stored = ShortcutSpec(keyCode: UInt32(clamping: code ?? -1),
                                  modifierBits: UInt8(clamping: bits ?? -1))
        self.activationShortcut = stored.isValid ? stored : .default
        let preferred = defaults.object(forKey: Key.preferredBandCount) as? Int ?? 0
        self.preferredBandCount = [0, 4, 5, 6].contains(preferred) ? preferred : 0
        self.highContrastEdges = defaults.object(forKey: Key.highContrast) as? Bool ?? true
        self.defaultZoom = min(4, max(1, defaults.object(forKey: Key.defaultZoom) as? Double ?? 2.0))
        self.showScanLine = defaults.object(forKey: Key.scanLine) as? Bool ?? false
        self.sharpPixels = defaults.object(forKey: Key.sharpPixels) as? Bool ?? false
        self.automaticallySpeak = defaults.object(forKey: Key.autoSpeak) as? Bool ?? false
        self.warningThreshold = min(95, max(50, defaults.object(forKey: Key.warningThreshold) as? Int ?? 75))
        self.averageWarningThreshold = min(85, max(40, defaults.object(forKey: Key.averageWarningThreshold) as? Int ?? 60))
        self.criticalBandThreshold = min(50, max(10, defaults.object(forKey: Key.criticalBandThreshold) as? Int ?? 25))
        self.rememberResultWindow = defaults.object(forKey: Key.rememberWindow) as? Bool ?? true
        self.speechRate = min(0.65, max(0.35, defaults.object(forKey: Key.speechRate) as? Double ?? 0.5))
        self.speechVoiceIdentifier = defaults.string(forKey: Key.speechVoice) ?? ""
        let sensitivity = defaults.object(forKey: Key.hoverSensitivity) as? Int ?? 1
        self.hoverSensitivity = (0...2).contains(sensitivity) ? sensitivity : 1
        refreshLoginItemStatus()
    }

    /// Only call after Carbon successfully registers the requested shortcut.
    func saveRegisteredShortcut(_ shortcut: ShortcutSpec) {
        guard shortcut.isValid else { return }
        activationShortcut = shortcut
        defaults.set(Int(shortcut.keyCode), forKey: Key.shortcutCode)
        defaults.set(Int(shortcut.modifierBits), forKey: Key.shortcutModifiers)
    }

    /// SMAppService registration requires a properly signed, stably installed
    /// application. In particular, Xcode's temporary build location is not a
    /// dependable way to evaluate launch-at-login support.
    func refreshLoginItemStatus() {
        switch SMAppService.mainApp.status {
        case .enabled:
            launchAtLoginEnabled = true
            loginItemMessage = nil
        case .requiresApproval:
            launchAtLoginEnabled = false
            loginItemMessage = "Approve Resistor Lens in System Settings → General → Login Items & Extensions."
        case .notFound:
            launchAtLoginEnabled = false
            loginItemMessage = "Login item is unavailable. Install a signed copy in Applications and retry."
        default:
            launchAtLoginEnabled = false
            loginItemMessage = nil
        }
    }

    func setLaunchAtLogin(_ enabled: Bool) {
        do {
            if enabled { try SMAppService.mainApp.register() }
            else { try SMAppService.mainApp.unregister() }
            refreshLoginItemStatus()
        } catch {
            refreshLoginItemStatus()
            loginItemMessage = "macOS could not \(enabled ? "enable" : "disable") Launch at Login: \(error.localizedDescription). Try a signed app installed in Applications."
        }
    }
}
