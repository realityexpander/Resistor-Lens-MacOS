import AppKit
import SwiftUI
import AVFoundation

// The color is a secondary visual cue; all options display plain English names.
extension BandColor {
    var swatch: Color {
        switch self {
        case .unknown: return Color(red: 0.48, green: 0.48, blue: 0.50)
        case .black: return Color(red: 0.09, green: 0.09, blue: 0.10)
        case .brown: return Color(red: 0.43, green: 0.23, blue: 0.11)
        case .red: return Color(red: 0.84, green: 0.12, blue: 0.13)
        case .orange: return Color(red: 0.96, green: 0.44, blue: 0.07)
        case .yellow: return Color(red: 0.96, green: 0.82, blue: 0.14)
        case .green: return Color(red: 0.10, green: 0.55, blue: 0.23)
        case .blue: return Color(red: 0.12, green: 0.31, blue: 0.79)
        case .violet: return Color(red: 0.55, green: 0.24, blue: 0.72)
        case .gray: return Color(red: 0.51, green: 0.51, blue: 0.51)
        case .white: return .white
        case .gold: return Color(red: 0.78, green: 0.60, blue: 0.18)
        case .silver: return Color(red: 0.75, green: 0.76, blue: 0.79)
        case .none: return .clear // An absent tolerance band is not painted.
        }
    }
}

struct BandEntry {
    var color: BandColor
    /// Nil if no evidence was available for that band.
    var confidencePercent: Int?
    var manuallyEdited: Bool = false
}

@MainActor
final class ResultState: ObservableObject {
    @Published var bandCount: Int
    @Published private(set) var entries: [BandEntry]
    let note: String
    let capturedCrop: CapturedResistorCrop?
    private let speaker = AVSpeechSynthesizer()
    private let speechSettings: AppSettings

    init(detection: DetectionResult, crop: CapturedResistorCrop? = nil,
         preferredBandCount: Int = 0, speechSettings: AppSettings) {
        self.speechSettings = speechSettings
        self.capturedCrop = crop
        self.bandCount = (4...6).contains(preferredBandCount) ? preferredBandCount :
                         ((4...6).contains(detection.bands.count) ? detection.bands.count : 4)
        self.entries = Array((detection.bands.map {
            BandEntry(color: $0.color, confidencePercent: $0.confidencePercent)
        } + Array(repeating: BandEntry(color: .unknown, confidencePercent: nil),
                  count: 6)).prefix(6))
        self.note = detection.note
    }

    var currentColors: [BandColor] {
        Array(entries.prefix(bandCount).map(\.color))
    }

    var reading: ResistorReading? { ResistorDecoder.decode(currentColors) }

    /// Review counts never convert heuristic confidence into a probability.
    /// Unrecognized bands and manually corrected bands are separate states.
    func bandsNeedingReview(threshold: Int) -> Int {
        entries.prefix(bandCount).filter { entry in
            !entry.manuallyEdited && (entry.confidencePercent ?? 0) < threshold
        }.count
    }

    func warningAssessment(averageThreshold: Int, criticalThreshold: Int) -> ConfidenceWarningAssessment {
        ConfidenceWarningAssessment.evaluate(entries.prefix(bandCount).map { entry in
            ConfidenceWarningInput(confidencePercent: entry.confidencePercent,
                                   manuallyEdited: entry.manuallyEdited)
        }, averageThreshold: averageThreshold, criticalThreshold: criticalThreshold)
    }

    var manuallyCorrectedBands: Int {
        entries.prefix(bandCount).filter(\.manuallyEdited).count
    }

    func setColor(_ newColor: BandColor, at index: Int) {
        guard (0..<bandCount).contains(index) else { return }
        entries[index].color = newColor
        // A manual selection is not assigned artificial 100% confidence.
        entries[index].manuallyEdited = true
    }

    func confidenceLabel(for index: Int) -> String {
        guard entries.indices.contains(index) else { return "Not detected" }
        let entry = entries[index]
        if entry.manuallyEdited { return "Manual override" }
        if let confidence = entry.confidencePercent { return "Confidence \(confidence)%" }
        return "Not detected"
    }

    func reverse() {
        let reversed = Array(entries.prefix(bandCount).reversed())
        for index in reversed.indices { entries[index] = reversed[index] }
    }

    func copyResult() {
        guard let reading else { return }
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(reading.fullDescription, forType: .string)
    }

    func speakResult() {
        guard let reading else { return }
        speaker.stopSpeaking(at: .immediate)
        let spoken = reading.fullDescription
            .replacingOccurrences(of: "Ω", with: " ohms ")
            .replacingOccurrences(of: "±", with: " plus or minus ")
        let utterance = AVSpeechUtterance(string: spoken)
        utterance.rate = Float(speechSettings.speechRate)
        if !speechSettings.speechVoiceIdentifier.isEmpty {
            utterance.voice = AVSpeechSynthesisVoice(identifier: speechSettings.speechVoiceIdentifier)
        }
        speaker.speak(utterance)
    }
}

/// Vector rendering: shaded ceramic barrel, metal leads, slightly separated
/// tolerance band, and shaded pigment. Remains crisp on Retina displays.
struct ResistorIllustration: View {
    let colors: [BandColor]
    let highContrastEdges: Bool

    private func positions(for count: Int) -> [CGFloat] {
        switch count {
        case 4: return [0.19, 0.36, 0.53, 0.79]
        case 5: return [0.15, 0.29, 0.43, 0.57, 0.80]
        case 6: return [0.13, 0.25, 0.37, 0.49, 0.69, 0.83]
        default: return []
        }
    }

    var body: some View {
        GeometryReader { geometry in
            let canvasWidth = geometry.size.width
            let bodyWidth = min(canvasWidth * 0.77, 415.0)
            let bodyHeight: CGFloat = 72
            let centerY = geometry.size.height / 2
            let bandCenters = positions(for: colors.count)
            let bandWidth = max(12, min(19, bodyWidth / 19))

            ZStack {
                // Subtle ground shadow creates depth without obscuring colors.
                Capsule()
                    .fill(Color.black.opacity(0.14))
                    .frame(width: bodyWidth * 0.90, height: 12)
                    .blur(radius: 9)
                    .position(x: canvasWidth / 2, y: centerY + bodyHeight / 2 + 13)

                Capsule()
                    .fill(LinearGradient(colors: [Color(white: 0.46),
                                                  Color(white: 0.88),
                                                  Color(white: 0.64),
                                                  Color(white: 0.39)],
                                         startPoint: .top, endPoint: .bottom))
                    .frame(width: canvasWidth * 0.96, height: 9)
                    .overlay(Capsule().stroke(Color.black.opacity(0.23), lineWidth: 0.7))
                    .position(x: canvasWidth / 2, y: centerY)

                RoundedRectangle(cornerRadius: bodyHeight * 0.40)
                    .fill(LinearGradient(stops: [
                        .init(color: Color(red: 0.59, green: 0.43, blue: 0.27), location: 0),
                        .init(color: Color(red: 0.91, green: 0.78, blue: 0.55), location: 0.15),
                        .init(color: Color(red: 0.97, green: 0.87, blue: 0.68), location: 0.36),
                        .init(color: Color(red: 0.84, green: 0.68, blue: 0.44), location: 0.78),
                        .init(color: Color(red: 0.53, green: 0.38, blue: 0.24), location: 1)
                    ], startPoint: .top, endPoint: .bottom))
                    .frame(width: bodyWidth, height: bodyHeight)
                    .overlay {
                        RoundedRectangle(cornerRadius: bodyHeight * 0.40)
                            .stroke(Color.black.opacity(0.30), lineWidth: 1)
                    }
                    .position(x: canvasWidth / 2, y: centerY)

                // Paint the bands onto the central barrel. All band colors are
                // still explicitly named in the editable rows underneath.
                ForEach(0..<colors.count, id: \.self) { index in
                    if colors[index] != .none && index < bandCenters.count {
                        Rectangle()
                            .fill(colors[index].swatch)
                            .overlay {
                                LinearGradient(colors: [Color.white.opacity(0.32),
                                                        Color.white.opacity(0.06),
                                                        Color.black.opacity(0.25)],
                                               startPoint: .top, endPoint: .bottom)
                            }
                            .overlay {
                                Rectangle()
                                    .strokeBorder(highContrastEdges ? Color.white :
                                                  Color.black.opacity(0.40),
                                                  lineWidth: highContrastEdges ? 2.2 : 0.8)
                            }
                            .overlay {
                                if highContrastEdges {
                                    Rectangle()
                                        .strokeBorder(Color.black, lineWidth: 1.0)
                                        .padding(.horizontal, 2.5)
                                }
                            }
                            .frame(width: bandWidth, height: bodyHeight - 3)
                            .position(x: (canvasWidth - bodyWidth) / 2 + bodyWidth * bandCenters[index],
                                      y: centerY)
                    }
                }

                // Reflective highlight on the lacquered body (subtle enough
                // not to change the perceived color of the band significantly).
                Capsule()
                    .fill(Color.white.opacity(0.10))
                    .frame(width: bodyWidth * 0.89, height: 8)
                    .blur(radius: 3)
                    .position(x: canvasWidth / 2, y: centerY - bodyHeight * 0.28)
            }
        }
        .frame(height: 126)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Illustration of \(colors.count)-band resistor: \(colors.map(\.rawValue).joined(separator: ", "))")
    }
}

struct ResultView: View {
    @ObservedObject var state: ResultState
    @ObservedObject var settings: AppSettings
    let rescan: () -> Void
    let showSettings: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Label("Resistor Lens", systemImage: "line.3.horizontal.decrease")
                        .font(.headline)
                    Spacer()
                    Text("v7 • Screen-image estimate")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button(action: showSettings) {
                        Image(systemName: "gearshape")
                    }
                    .help("Settings… (⌘,)")
                    .accessibilityLabel("Open Settings")
                }

                // Always place this warning above the large numeric result.
                // The summary recalculates when any band, band count, or threshold changes.
                let warning = state.warningAssessment(
                    averageThreshold: settings.averageWarningThreshold,
                    criticalThreshold: settings.criticalBandThreshold
                )
                if warning.shouldWarn {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(.black)
                            .accessibilityHidden(true)
                        VStack(alignment: .leading, spacing: 5) {
                            Text("WARNING: LOW CONFIDENCE")
                                .font(.system(size: 19, weight: .black))
                                .foregroundColor(.black)
                            Text(warning.details)
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.black)
                                .fixedSize(horizontal: false, vertical: true)
                            Text("Check the magnified image and correct the uncertain colors before relying on this reading.")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.black)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(red: 1.0, green: 0.87, blue: 0.26),
                                in: RoundedRectangle(cornerRadius: 11))
                    .overlay(RoundedRectangle(cornerRadius: 11)
                        .strokeBorder(Color.black, lineWidth: 2))
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel("Warning: low confidence. " + warning.details)
                }

                VStack(spacing: 3) {
                    if let reading = state.reading {
                        Text(reading.formattedResistance)
                            .font(.system(size: 38, weight: .bold, design: .rounded))
                            .minimumScaleFactor(0.6)
                            .lineLimit(1)
                            .accessibilityLabel("Estimated resistance: \(reading.formattedResistance)")
                        Text(reading.formattedTolerance + " tolerance" +
                             (reading.ppmPerKelvin.map { " • \($0) ppm/K" } ?? ""))
                            .font(.subheadline)
                    } else {
                        Text("Review band colors")
                            .font(.system(size: 26, weight: .semibold))
                        Text("Choose valid colors below to calculate resistance")
                            .foregroundStyle(.secondary)
                            .font(.subheadline)
                    }
                }
                .frame(maxWidth: .infinity)

                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Captured resistor · magnifier")
                            .font(.headline)
                        if let crop = state.capturedCrop {
                            SourceCropView(crop: crop, settings: settings)
                        } else {
                            Text("Could not create a crop from this selection. Try drawing the line again.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity, minHeight: 150)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
                    .background(Color(nsColor: .controlBackgroundColor).opacity(0.55),
                                in: RoundedRectangle(cornerRadius: 12))

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Decoded resistor · live preview")
                            .font(.headline)
                        ResistorIllustration(colors: state.currentColors,
                                             highContrastEdges: settings.highContrastEdges)
                            .frame(height: 150)
                            .frame(maxWidth: .infinity)
                            .background(Color(nsColor: .textBackgroundColor),
                                        in: RoundedRectangle(cornerRadius: 8))
                        Toggle("High-contrast band edges", isOn: $settings.highContrastEdges)
                            .toggleStyle(.checkbox)
                            .font(.caption)
                        Text("Generated illustration updates when you correct a color below.")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
                    .background(Color(nsColor: .controlBackgroundColor).opacity(0.55),
                                in: RoundedRectangle(cornerRadius: 12))
                }

                Picker("Number of bands", selection: $state.bandCount) {
                    Text("4 bands").tag(4)
                    Text("5 bands").tag(5)
                    Text("6 bands").tag(6)
                }
                .pickerStyle(.segmented)

                HStack(spacing: 8) {
                    let reviewCount = state.bandsNeedingReview(threshold: settings.warningThreshold)
                    Image(systemName: reviewCount > 0 ? "exclamationmark.triangle" : "info.circle")
                        .foregroundStyle(reviewCount > 0 ? Color.orange : Color.secondary)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Average detected confidence: " + (warning.averagePercent.map {
                            String(format: "%.1f%% across %d band%@", $0, warning.evaluatedCount,
                                   warning.evaluatedCount == 1 ? "" : "s")
                        } ?? "N/A") + " (manual corrections excluded)")
                        Text("Review flags: \(reviewCount) • Manually corrected: \(state.manuallyCorrectedBands) • Per-band review hint: \(settings.warningThreshold)%")
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    Spacer()
                }
                .accessibilityElement(children: .combine)

                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Band editor").font(.headline)
                        Spacer()
                        Text("Choose color and its position-specific value")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    ForEach(0..<state.bandCount, id: \.self) { index in
                        let role = BandRole.at(index, total: state.bandCount)
                        let color = state.entries[index].color

                        HStack(spacing: 12) {
                            RoundedRectangle(cornerRadius: 4)
                                .fill(color.swatch)
                                .frame(width: 25, height: 35)
                                .overlay {
                                    RoundedRectangle(cornerRadius: 4)
                                        .strokeBorder(Color.white.opacity(0.9), lineWidth: 2)
                                }
                                .overlay {
                                    RoundedRectangle(cornerRadius: 4)
                                        .strokeBorder(Color.black.opacity(0.6), lineWidth: 0.8)
                                }
                                .accessibilityHidden(true)

                            VStack(alignment: .leading, spacing: 3) {
                                Text("Band \(index + 1) · \(role.title)")
                                    .font(.subheadline.weight(.medium))
                                Text(state.confidenceLabel(for: index))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                if !state.entries[index].manuallyEdited,
                                   let confidence = state.entries[index].confidencePercent,
                                   confidence < settings.warningThreshold {
                                    Label("Review color", systemImage: "exclamationmark.triangle")
                                        .font(.caption2.weight(.semibold))
                                        .foregroundStyle(.orange)
                                }
                            }

                            Spacer(minLength: 6)

                            Picker("Band \(index + 1) \(role.title)", selection: Binding(
                                get: { state.entries[index].color },
                                set: { state.setColor($0, at: index) }
                            )) {
                                ForEach(role.allowedColors) { option in
                                    Text(role.menuLabel(for: option)).tag(option)
                                }
                                if !role.allowedColors.contains(color) {
                                    Text("\(color.rawValue) — invalid for this position")
                                        .tag(color)
                                }
                            }
                            .labelsHidden()
                            .pickerStyle(.menu)
                            .frame(width: 200, alignment: .trailing)
                            .accessibilityLabel("Band \(index + 1), \(role.title), \(state.confidenceLabel(for: index))")
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                        .background(Color(nsColor: .controlBackgroundColor).opacity(0.55),
                                    in: RoundedRectangle(cornerRadius: 9))
                    }
                }

                Text(state.note)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Confidence percentages are uncalibrated color-match estimates, not accuracy probabilities. A manual override does not imply 100% confidence.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 8) {
                    Button("Reverse order") { state.reverse() }
                    Spacer()
                    Button("Speak") { state.speakResult() }
                        .disabled(state.reading == nil)
                    Button("Copy") { state.copyResult() }
                        .disabled(state.reading == nil)
                    Button("Try again") { rescan() }
                        .buttonStyle(.borderedProminent)
                }

                Text("Verify the result with a multimeter before using the resistor in a circuit.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .padding(18)
        }
        .frame(minWidth: 710, minHeight: 620)
        .onExitCommand { NSApp.keyWindow?.close() }
    }
}
