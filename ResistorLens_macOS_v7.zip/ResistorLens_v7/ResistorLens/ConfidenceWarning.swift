import Foundation

/// A display-only assessment of the existing detector's heuristic scores.
/// It does not reclassify colors, alter the scan, or claim calibrated accuracy.
struct ConfidenceWarningInput {
    let confidencePercent: Int?
    let manuallyEdited: Bool
}

struct ConfidenceWarningAssessment {
    let averagePercent: Double?
    let evaluatedCount: Int
    let manualCount: Int
    /// 1-based indices of active bands for which the scanner returned no score.
    let missingBandNumbers: [Int]
    /// 1-based band positions and their detector scores below the critical limit.
    let criticalBands: [(number: Int, percent: Int)]
    let averageBelowThreshold: Bool
    let averageThreshold: Int
    let criticalThreshold: Int

    var shouldWarn: Bool {
        averageBelowThreshold || !criticalBands.isEmpty || !missingBandNumbers.isEmpty
    }

    /// Precise explanation to accompany the high-contrast warning banner.
    /// A manual override is excluded rather than assigned fictional 100% confidence.
    var details: String {
        var reasons: [String] = []
        if averageBelowThreshold, let averagePercent {
            reasons.append(String(format: "Average %.1f%% across %d unedited detected band%@ is below %d%%.",
                                  averagePercent, evaluatedCount,
                                  evaluatedCount == 1 ? "" : "s", averageThreshold))
        }
        if !criticalBands.isEmpty {
            let bands = criticalBands.map { "Band \($0.number): \($0.percent)%" }.joined(separator: ", ")
            reasons.append("\(bands) below \(criticalThreshold)%.")
        }
        if !missingBandNumbers.isEmpty {
            let bands = missingBandNumbers.map { "Band \($0)" }.joined(separator: ", ")
            reasons.append("\(bands) not detected; verify manually.")
        }
        return reasons.joined(separator: " ")
    }

    static func evaluate(_ inputs: [ConfidenceWarningInput],
                         averageThreshold: Int = 60,
                         criticalThreshold: Int = 25) -> ConfidenceWarningAssessment {
        let avgLimit = max(0, min(100, averageThreshold))
        let criticalLimit = max(0, min(100, criticalThreshold))
        var scores: [Int] = []
        var missing: [Int] = []
        var critical: [(number: Int, percent: Int)] = []
        var manualCount = 0

        for (index, entry) in inputs.enumerated() {
            if entry.manuallyEdited {
                manualCount += 1
                continue
            }
            guard let score = entry.confidencePercent else {
                missing.append(index + 1)
                continue
            }
            // Defensive clipping: the detector currently produces scores 10...98.
            let percent = max(0, min(100, score))
            scores.append(percent)
            if percent < criticalLimit {
                critical.append((index + 1, percent))
            }
        }

        let mean: Double? = scores.isEmpty ? nil :
            Double(scores.reduce(0, +)) / Double(scores.count)
        return ConfidenceWarningAssessment(
            averagePercent: mean, evaluatedCount: scores.count,
            manualCount: manualCount, missingBandNumbers: missing,
            criticalBands: critical, averageBelowThreshold: mean.map { $0 < Double(avgLimit) } ?? false,
            averageThreshold: avgLimit, criticalThreshold: criticalLimit
        )
    }
}
