import AppKit
import SwiftUI

/// Side-by-side reference to the actual pixels from the captured display.
/// Fit shows the entire selected region; magnification is user-controlled.
/// At higher zoom levels, drag the picture to inspect the end bands.
struct SourceCropView: View {
    let crop: CapturedResistorCrop
    @ObservedObject var settings: AppSettings

    @State private var zoom = 1.0
    @State private var pan = CGSize.zero
    @GestureState private var drag = CGSize.zero

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            GeometryReader { proxy in
                let viewport = proxy.size
                let imageWidth = CGFloat(crop.image.width)
                let imageHeight = CGFloat(crop.image.height)
                let fit = min(viewport.width / imageWidth,
                              viewport.height / imageHeight)
                let fittedWidth = imageWidth * fit
                let fittedHeight = imageHeight * fit
                let maxPanX = max(0, (fittedWidth * zoom - viewport.width) / 2)
                let maxPanY = max(0, (fittedHeight * zoom - viewport.height) / 2)

                ZStack {
                    Color(nsColor: .textBackgroundColor)

                    Image(decorative: crop.image, scale: 1.0)
                        .resizable()
                        .interpolation(settings.sharpPixels ? .none : .high)
                        .frame(width: fittedWidth, height: fittedHeight)
                        .overlay {
                            if settings.showScanLine {
                                GeometryReader { imageGeometry in
                                    Path { path in
                                        let y = imageGeometry.size.height / 2
                                        path.move(to: CGPoint(x: imageGeometry.size.width * crop.scanStartX, y: y))
                                        path.addLine(to: CGPoint(x: imageGeometry.size.width * crop.scanEndX, y: y))
                                    }
                                    .stroke(Color.cyan, style: StrokeStyle(lineWidth: 1.6,
                                                                          lineCap: .round,
                                                                          dash: [6, 4]))
                                    .shadow(color: .black.opacity(0.9), radius: 2)
                                }
                            }
                        }
                        .scaleEffect(zoom)
                        .offset(x: Self.clamp(pan.width + drag.width, extent: maxPanX),
                                y: Self.clamp(pan.height + drag.height, extent: maxPanY))
                        .gesture(
                            DragGesture(minimumDistance: 3)
                                .updating($drag) { value, state, _ in
                                    state = value.translation
                                }
                                .onEnded { value in
                                    pan = CGSize(
                                        width: Self.clamp(pan.width + value.translation.width,
                                                          extent: maxPanX),
                                        height: Self.clamp(pan.height + value.translation.height,
                                                           extent: maxPanY))
                                }
                        )
                        .onTapGesture(count: 2) {
                            zoom = 1.0
                            pan = .zero
                        }
                }
                .frame(width: viewport.width, height: viewport.height)
                .clipped()
                .overlay {
                    RoundedRectangle(cornerRadius: 8)
                        .strokeBorder(Color.secondary.opacity(0.3), lineWidth: 1)
                }
                .clipShape(RoundedRectangle(cornerRadius: 8))
            }
            .frame(height: 150)
            .accessibilityLabel("Magnified captured resistor image")
            .accessibilityHint("Use the zoom control below. Drag to pan at higher magnification.")

            HStack(spacing: 9) {
                Text("Zoom")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Slider(value: $zoom, in: 1.0...4.0, step: 0.25)
                    .accessibilityLabel("Captured resistor magnification")
                    .onChange(of: zoom) { _, _ in pan = .zero }
                Text(String(format: "%.2f×", zoom))
                    .font(.caption.monospacedDigit())
                    .frame(width: 46, alignment: .trailing)
                Button("Fit") {
                    zoom = 1.0
                    pan = .zero
                }
                .buttonStyle(.borderless)
                .font(.caption)
            }

            HStack(spacing: 14) {
                Toggle("Scan line", isOn: $settings.showScanLine)
                Toggle("Sharp pixels", isOn: $settings.sharpPixels)
            }
            .font(.caption)
            .toggleStyle(.checkbox)

            Text("Actual screenshot pixels, aligned horizontally. At higher zoom, drag to pan; double-click to reset.")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .onAppear { zoom = settings.defaultZoom }
    }

    private static func clamp(_ value: CGFloat, extent: CGFloat) -> CGFloat {
        min(max(value, -extent), extent)
    }
}
