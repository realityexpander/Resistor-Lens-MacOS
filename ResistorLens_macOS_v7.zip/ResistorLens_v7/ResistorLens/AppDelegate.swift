import AppKit
import SwiftUI
import CoreGraphics

final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    private let settings = AppSettings()
    private let resultFrameName = "ResistorLensResultFrame"
    private var statusItem: NSStatusItem?
    private var readMenuItem: NSMenuItem?
    private var preferencesKeyMonitor: Any?
    private var hotKey: GlobalHotKey?
    private var selectionWindow: NSWindow?
    private var resultWindow: EscapeClosingPanel?
    private var settingsWindow: EscapeClosingPanel?
    private var retainedResult: ResultState?
    private var isCapturing = false

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory) // menu-bar utility; no Dock icon
        installApplicationMenu()
        // A menu-bar-only accessory may not expose the usual app menu in all
        // contexts, so recognize ⌘, locally whenever Resistor Lens is active.
        // This is NOT a global override of another application's ⌘, shortcut.
        preferencesKeyMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            let flags = event.modifierFlags.intersection([.command, .shift, .option, .control])
            if (event.keyCode == 43 || event.charactersIgnoringModifiers == ",") && flags == .command {
                self?.showSettings()
                return nil
            }
            return event
        }

        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        item.button?.image = NSImage(systemSymbolName: "line.3.horizontal.decrease",
                                     accessibilityDescription: "Resistor Lens")
        let menu = NSMenu()
        let read = NSMenuItem(title: "Read resistor", action: #selector(startFromMenu), keyEquivalent: "")
        read.target = self
        menu.addItem(read)
        readMenuItem = read

        let preferences = NSMenuItem(title: "Settings…", action: #selector(showSettings),
                                     keyEquivalent: ",")
        preferences.keyEquivalentModifierMask = [.command]
        preferences.target = self
        menu.addItem(preferences)
        menu.addItem(.separator())

        let help = NSMenuItem(title: "How to use", action: #selector(showInstructions),
                              keyEquivalent: "")
        help.target = self
        menu.addItem(help)
        let quit = NSMenuItem(title: "Quit Resistor Lens", action: #selector(quitApp),
                              keyEquivalent: "q")
        quit.target = self
        menu.addItem(quit)
        item.menu = menu
        statusItem = item

        hotKey = GlobalHotKey(initialShortcut: settings.activationShortcut) { [weak self] in
            self?.startCapture()
        }
        updateShortcutDisplay()
    }

    private func installApplicationMenu() {
        // When Resistor Lens is active, ⌘, opens Settings via macOS's ordinary
        // application menu. The menu-bar item remains accessible at all times.
        let main = NSMenu(title: "Main")
        let appItem = NSMenuItem()
        let appMenu = NSMenu(title: "Resistor Lens")
        let preferences = NSMenuItem(title: "Settings…", action: #selector(showSettings),
                                     keyEquivalent: ",")
        preferences.keyEquivalentModifierMask = [.command]
        preferences.target = self
        appMenu.addItem(preferences)
        appMenu.addItem(.separator())
        let quit = NSMenuItem(title: "Quit Resistor Lens", action: #selector(quitApp),
                              keyEquivalent: "q")
        quit.target = self
        appMenu.addItem(quit)
        main.addItem(appItem)
        appItem.submenu = appMenu
        NSApp.mainMenu = main
    }

    func applicationWillTerminate(_ notification: Notification) {
        if let preferencesKeyMonitor { NSEvent.removeMonitor(preferencesKeyMonitor) }
        if settings.rememberResultWindow, let resultWindow {
            resultWindow.saveFrame(usingName: resultFrameName)
        }
    }

    @objc private func startFromMenu() { startCapture() }
    @objc private func quitApp() { NSApp.terminate(nil) }

    @objc private func showSettings() {
        settings.refreshLoginItemStatus()
        if let settingsWindow {
            settingsWindow.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            return
        }
        let content = SettingsView(settings: settings,
                                   registerShortcut: { [weak self] in self?.changeShortcut(to: $0) ?? "App is unavailable." },
                                   recordingChanged: { [weak self] recording in
                                       if recording { self?.hotKey?.suspend() }
                                       else {
                                           if let self {
                                               _ = self.hotKey?.register(self.settings.activationShortcut)
                                               self.updateShortcutDisplay()
                                           }
                                       }
                                   })
        let panel = EscapeClosingPanel(contentRect: CGRect(x: 0, y: 0, width: 620, height: 730),
                                       styleMask: [.titled, .closable],
                                       backing: .buffered, defer: false)
        panel.title = "Resistor Lens Settings"
        panel.isFloatingPanel = true
        panel.level = .floating
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.delegate = self
        panel.contentView = NSHostingView(rootView: content)
        panel.center()
        settingsWindow = panel
        panel.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    private func changeShortcut(to proposed: ShortcutSpec) -> String? {
        guard proposed.isValid else { return "Choose at least two modifiers and a letter or number." }
        guard let hotKey else { return "Global shortcut service could not start." }
        let status = hotKey.register(proposed)
        guard status == noErr else {
            return "macOS could not register \(proposed.displayName) (error \(status)). The previous shortcut is unchanged. Try another combination."
        }
        settings.saveRegisteredShortcut(proposed)
        updateShortcutDisplay()
        return nil
    }

    private func updateShortcutDisplay() {
        let combination = settings.activationShortcut.displayName
        let enabled = hotKey?.registrationStatus == noErr
        settings.shortcutAvailable = enabled
        statusItem?.button?.toolTip = "Resistor Lens: \(enabled ? combination : "No registered global shortcut")"
        readMenuItem?.title = enabled ? "Read resistor (\(combination))" : "Read resistor (shortcut unavailable)"
    }

    @objc private func showInstructions() {
        let alert = NSAlert()
        alert.messageText = "Resistor Lens"
        alert.informativeText = "Press \(settings.activationShortcut.displayName) anywhere on your Mac (or use the menu-bar icon). Drag from the CENTER of the first color band to the CENTER of the last band, in reading order. Esc cancels selection or closes the result. Use Settings… (⌘,) to change the hotkey, zoom, contrast and feedback options."
        alert.addButton(withTitle: "OK")
        alert.runModal()
    }

    private func startCapture() {
        guard selectionWindow == nil && !isCapturing else { return }
        resultWindow?.close()
        resultWindow = nil
        retainedResult = nil

        if !CGPreflightScreenCaptureAccess() {
            _ = CGRequestScreenCaptureAccess()
            if !CGPreflightScreenCaptureAccess() {
                showError("Screen Recording permission required",
                          "Enable Resistor Lens under System Settings → Privacy & Security → Screen & System Audio Recording (or Screen Recording). Then quit and reopen the app.")
                return
            }
        }
        let position = NSEvent.mouseLocation
        guard let screen = NSScreen.screens.first(where: { $0.frame.contains(position) }) ?? NSScreen.main else {
            showError("No display found", "Move the pointer onto an active display and try again.")
            return
        }

        isCapturing = true
        Task { @MainActor [weak self] in
            do {
                let captured = try await ScreenCapture.image(of: screen)
                self?.isCapturing = false
                self?.showSelection(screen: screen, image: captured)
            } catch {
                self?.isCapturing = false
                self?.showError("Screen capture failed", "\(error.localizedDescription)\n\nCheck Screen Recording permission in System Settings.")
            }
        }
    }

    @MainActor private func showSelection(screen: NSScreen, image: CGImage) {
        let overlay = NSWindow(contentRect: screen.frame, styleMask: .borderless,
                               backing: .buffered, defer: false)
        overlay.level = .screenSaver
        overlay.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        overlay.isOpaque = false
        overlay.backgroundColor = .clear
        overlay.hasShadow = false
        overlay.ignoresMouseEvents = false
        overlay.acceptsMouseMovedEvents = true

        let view = SelectionOverlay(frame: CGRect(origin: .zero, size: screen.frame.size))
        view.onCancel = { [weak self] in self?.closeSelection() }
        view.onSelection = { [weak self] start, end in
            guard let self else { return }
            self.closeSelection()
            let detection = ColorBandDetector.detect(image: image,
                                                     screenFrame: screen.frame,
                                                     from: start, to: end)
            let crop = ResistorCrop.make(image: image, screenFrame: screen.frame,
                                         from: start, to: end)
            self.showResult(detection, crop: crop, on: screen, near: end)
        }
        overlay.contentView = view
        selectionWindow = overlay
        overlay.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        overlay.makeFirstResponder(view)
    }

    @MainActor private func closeSelection() {
        selectionWindow?.orderOut(nil)
        selectionWindow = nil
    }

    @MainActor private func showResult(_ detection: DetectionResult,
                                       crop: CapturedResistorCrop?,
                                       on screen: NSScreen,
                                       near point: CGPoint) {
        let state = ResultState(detection: detection, crop: crop,
                                preferredBandCount: settings.preferredBandCount,
                                speechSettings: settings)
        retainedResult = state
        let content = ResultView(state: state, settings: settings,
                                 rescan: { [weak self] in self?.startCapture() },
                                 showSettings: { [weak self] in self?.showSettings() })
        let hosting = NSHostingView(rootView: content)
        let windowSize = NSSize(width: 820, height: 790)
        let panel = EscapeClosingPanel(contentRect: CGRect(origin: .zero, size: windowSize),
                                       styleMask: [.titled, .closable, .resizable],
                                       backing: .buffered, defer: false)
        panel.title = "Resistor Lens"
        panel.isFloatingPanel = true
        panel.level = .floating
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.delegate = self
        panel.contentView = hosting
        panel.contentMinSize = NSSize(width: 710, height: 620)
        panel.contentMaxSize = NSSize(width: 1200, height: 1200)
        // AppKit persists the full frame (position and size) in UserDefaults.
        // Save only on close so the user can disable remembering at any time.
        let restored = settings.rememberResultWindow && panel.setFrameUsingName(resultFrameName)
        if !restored || !NSScreen.screens.contains(where: {
            let visiblePart = $0.visibleFrame.intersection(panel.frame)
            return visiblePart.width >= 200 && visiblePart.height >= 150
        }) {
            let visible = screen.visibleFrame
            let x = max(visible.minX, min(point.x + 20, visible.maxX - windowSize.width))
            let y = max(visible.minY, min(point.y - windowSize.height / 2,
                                         visible.maxY - windowSize.height))
            panel.setFrameOrigin(NSPoint(x: x, y: y))
        }
        resultWindow = panel
        panel.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        if settings.automaticallySpeak { state.speakResult() }
    }

    func windowWillClose(_ notification: Notification) {
        guard let window = notification.object as? NSWindow else { return }
        if window === resultWindow {
            if settings.rememberResultWindow { window.saveFrame(usingName: resultFrameName) }
            resultWindow = nil
            retainedResult = nil // release the captured crop when result closes
        }
        if window === settingsWindow { settingsWindow = nil }
    }

    private func showError(_ title: String, _ detail: String) {
        let alert = NSAlert()
        alert.alertStyle = .warning
        alert.messageText = title
        alert.informativeText = detail
        alert.addButton(withTitle: "OK")
        alert.runModal()
    }
}
