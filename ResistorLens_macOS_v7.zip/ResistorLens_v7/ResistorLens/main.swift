import AppKit

// AppKit entry point makes the app work as a menu bar-only utility.
let application = NSApplication.shared
let applicationDelegate = AppDelegate()
application.delegate = applicationDelegate
application.run()
