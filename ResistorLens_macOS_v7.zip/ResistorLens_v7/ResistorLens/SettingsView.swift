import AppKit
import SwiftUI
import AVFoundation
import ServiceManagement

/// Owns a short-lived, application-local key event monitor. The monitor
/// captures its owner weakly so closing Settings can never leave a retained
/// window or global keystroke listener behind.
private final class ShortcutRecorder: ObservableObject {
    @Published private(set) var recording = false
    @Published var message = ""
    private var monitor: Any?
    private var onStopped: (() -> Void)?

    func begin(register: @escaping (ShortcutSpec) -> String?,
               onStopped: @escaping () -> Void) {
        guard !recording else { return }
        recording = true
        message = ""
        self.onStopped = onStopped
        monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, self.recording else { return event }
            if event.keyCode == 53 { // Esc cancels shortcut recording only
                self.stop()
                return nil
            }
            if event.isARepeat { return nil }
            var flags: UInt8 = 0
            if event.modifierFlags.contains(.shift) { flags |= ShortcutSpec.shift }
            if event.modifierFlags.contains(.option) { flags |= ShortcutSpec.option }
            if event.modifierFlags.contains(.control) { flags |= ShortcutSpec.control }
            if event.modifierFlags.contains(.command) { flags |= ShortcutSpec.command }
            let proposed = ShortcutSpec(keyCode: UInt32(event.keyCode), modifierBits: flags)
            if !proposed.isValid {
                self.message = "Use at least two modifiers with an A–Z or 0–9 key."
                NSSound.beep()
            } else if let issue = register(proposed) {
                self.message = issue
                NSSound.beep()
            } else {
                self.message = ""
                self.stop()
            }
            return nil // don't dispatch this recorded shortcut to a UI control
        }
    }

    func reset(register: (ShortcutSpec) -> String?) {
        if let issue = register(.default) { message = issue; NSSound.beep() }
        else { message = "" }
    }

    func stop() {
        guard recording else { return }
        if let monitor { NSEvent.removeMonitor(monitor); self.monitor = nil }
        recording = false
        let callback = onStopped
        onStopped = nil
        callback?()
    }

    deinit {
        if let monitor { NSEvent.removeMonitor(monitor) }
        onStopped?() // defensive restore if the window disappears mid-recording
    }
}

/// Accessible Settings dialog. Shortcut recording only occurs after clicking
/// Record, and never uses a systemwide keyboard monitor.
struct SettingsView: View {
    @ObservedObject var settings: AppSettings
    let registerShortcut: (ShortcutSpec) -> String?
    let recordingChanged: (Bool) -> Void
    @StateObject private var recorder = ShortcutRecorder()
    @State private var voicePreview = AVSpeechSynthesizer()
    private var voiceOptions: [AVSpeechSynthesisVoice] {
        AVSpeechSynthesisVoice.speechVoices().sorted { a, b in
            let aEnglish = a.language.hasPrefix("en")
            let bEnglish = b.language.hasPrefix("en")
            if aEnglish != bEnglish { return aEnglish }
            if a.language != b.language { return a.language < b.language }
            return a.name.localizedStandardCompare(b.name) == .orderedAscending
        }
    }

    private func testVoice() {
        voicePreview.stopSpeaking(at: .immediate)
        let phrase = AVSpeechUtterance(string: "Four point seven kilo ohms, plus or minus five percent.")
        phrase.rate = Float(settings.speechRate)
        if !settings.speechVoiceIdentifier.isEmpty {
            phrase.voice = AVSpeechSynthesisVoice(identifier: settings.speechVoiceIdentifier)
        }
        voicePreview.speak(phrase)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
            Text("Resistor Lens Settings")
                .font(.title2.bold())

            GroupBox("Activation") {
                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 12) {
                        Text("Global shortcut")
                            .frame(width: 120, alignment: .leading)
                        Text(settings.activationShortcut.displayName)
                            .font(.system(.headline, design: .monospaced))
                            .frame(minWidth: 70)
                            .accessibilityLabel("Current shortcut: \(settings.activationShortcut.displayName)")
                        Spacer()
                        Button(recorder.recording ? "Cancel recording" : "Record Shortcut…") {
                            if recorder.recording { recorder.stop() }
                            else {
                                recordingChanged(true)
                                recorder.begin(register: registerShortcut) {
                                    recordingChanged(false)
                                }
                            }
                        }
                        Button("Reset") { recorder.reset(register: registerShortcut) }
                            .disabled(recorder.recording)
                    }
                    Text(recorder.recording ? "Press two or more modifiers plus a letter or number. Esc cancels recording." :
                                                   "Example: Shift–Option–R. Only letters and numbers with at least two modifiers are supported.")
                        .font(.caption)
                        .foregroundStyle(recorder.recording ? Color.accentColor : Color.secondary)
                    if !settings.shortcutAvailable && !recorder.recording {
                        Label("The current global shortcut is unavailable. Record another one or use Reset.",
                              systemImage: "exclamationmark.triangle")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                    if !recorder.message.isEmpty {
                        Text(recorder.message)
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                }
                .padding(6)
            }

            GroupBox("Reading defaults and visibility") {
                VStack(alignment: .leading, spacing: 11) {
                    Picker("Initial number of bands", selection: $settings.preferredBandCount) {
                        Text("Automatic").tag(0)
                        Text("4 bands").tag(4)
                        Text("5 bands").tag(5)
                        Text("6 bands").tag(6)
                    }
                    Toggle("High-contrast black/white band edges", isOn: $settings.highContrastEdges)
                    Toggle("Show scan line by default", isOn: $settings.showScanLine)
                    Toggle("Sharp pixels by default", isOn: $settings.sharpPixels)
                    HStack(spacing: 10) {
                        Text("Initial zoom")
                            .frame(width: 90, alignment: .leading)
                        Slider(value: $settings.defaultZoom, in: 1...4, step: 0.25)
                        Text(String(format: "%.2f×", settings.defaultZoom))
                            .font(.system(.body, design: .monospaced))
                            .frame(width: 60, alignment: .trailing)
                    }
                }
                .padding(6)
            }

            GroupBox("Startup and windows") {
                VStack(alignment: .leading, spacing: 10) {
                    Toggle("Launch Resistor Lens at Login", isOn: Binding(
                        get: { settings.launchAtLoginEnabled },
                        set: { settings.setLaunchAtLogin($0) }
                    ))
                    if let message = settings.loginItemMessage {
                        Label(message, systemImage: "info.circle")
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .fixedSize(horizontal: false, vertical: true)
                        if SMAppService.mainApp.status == .requiresApproval {
                            Button("Open Login Items Settings…") {
                                SMAppService.openSystemSettingsLoginItems()
                            }
                        }
                    }
                    Text("For reliable login-item registration, run an installed, signed app from Applications, rather than an Xcode temporary build.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Toggle("Remember result window position and size",
                           isOn: $settings.rememberResultWindow)
                    Text("The result window position is saved when it closes; if disabled, new results appear near your last selection.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(6)
            }

            GroupBox("Feedback and speech") {
                VStack(alignment: .leading, spacing: 11) {
                    Toggle("Speak resistance automatically after a successful detection",
                           isOn: $settings.automaticallySpeak)
                    Picker("Speech voice", selection: $settings.speechVoiceIdentifier) {
                        Text("System default").tag("")
                        ForEach(voiceOptions, id: \.identifier) { voice in
                            Text("\(voice.name) (\(voice.language))").tag(voice.identifier)
                        }
                    }
                    HStack(spacing: 10) {
                        Text("Speech rate").frame(width: 100, alignment: .leading)
                        Text("Slow").font(.caption).foregroundStyle(.secondary)
                        Slider(value: $settings.speechRate, in: 0.35...0.65, step: 0.025)
                        Text("Fast").font(.caption).foregroundStyle(.secondary)
                        Text(String(format: "%.2f", settings.speechRate))
                            .font(.system(.body, design: .monospaced))
                            .frame(width: 44, alignment: .trailing)
                    }
                    HStack {
                        Spacer()
                        Button("Test Voice") { testVoice() }
                    }
                    HStack(spacing: 10) {
                        Text("Per-band review hint")
                            .frame(width: 135, alignment: .leading)
                        Slider(value: Binding(
                            get: { Double(settings.warningThreshold) },
                            set: { settings.warningThreshold = Int($0.rounded()) }
                        ), in: 50...95, step: 5)
                        Text("\(settings.warningThreshold)%")
                            .font(.system(.body, design: .monospaced))
                            .frame(width: 45, alignment: .trailing)
                    }
                    Divider()
                    Text("Prominent yellow warning banner")
                        .font(.subheadline.weight(.semibold))
                    HStack(spacing: 10) {
                        Text("Average below")
                            .frame(width: 135, alignment: .leading)
                        Slider(value: Binding(
                            get: { Double(settings.averageWarningThreshold) },
                            set: { settings.averageWarningThreshold = Int($0.rounded()) }
                        ), in: 40...85, step: 5)
                        Text("\(settings.averageWarningThreshold)%")
                            .font(.system(.body, design: .monospaced))
                            .frame(width: 45, alignment: .trailing)
                    }
                    HStack(spacing: 10) {
                        Text("Any band below")
                            .frame(width: 135, alignment: .leading)
                        Slider(value: Binding(
                            get: { Double(settings.criticalBandThreshold) },
                            set: { settings.criticalBandThreshold = Int($0.rounded()) }
                        ), in: 10...50, step: 5)
                        Text("\(settings.criticalBandThreshold)%")
                            .font(.system(.body, design: .monospaced))
                            .frame(width: 45, alignment: .trailing)
                    }
                    Text("The banner also appears if any active band was not detected. Manually corrected bands have no detector confidence and are excluded from the average. The separate per-band review hint above remains available.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("Confidence scores are image-matching heuristics, not measured probabilities.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(6)
            }

            GroupBox("Automatic hover detection — future feature") {
                VStack(alignment: .leading, spacing: 10) {
                    Picker("Hover detection sensitivity", selection: $settings.hoverSensitivity) {
                        Text("Low · fewer false detections").tag(0)
                        Text("Balanced").tag(1)
                        Text("High · find faint bands").tag(2)
                    }
                    Text("Saved for the planned automatic cursor-hover mode. This setting does not currently affect line-selection recognition, and automatic hover scanning is not yet implemented.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(6)
            }

            HStack {
                Text("Saved automatically on this Mac. Screenshots stay in memory.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button("Done") { NSApp.keyWindow?.close() }
                    .keyboardShortcut(.defaultAction)
            }
            }
            .padding(22)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(width: 620)
        .onDisappear {
            recorder.stop()
            voicePreview.stopSpeaking(at: .immediate)
        }
    }
}
