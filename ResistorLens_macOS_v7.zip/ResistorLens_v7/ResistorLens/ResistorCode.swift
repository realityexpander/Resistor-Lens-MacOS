import Foundation

/// The printed name, rather than the swatch, is always the source of truth.
/// `.none` is meaningful only for tolerance (an unmarked ±20% resistor).
enum BandColor: String, CaseIterable, Identifiable, Codable {
    case unknown = "Uncertain"
    case black = "Black"
    case brown = "Brown"
    case red = "Red"
    case orange = "Orange"
    case yellow = "Yellow"
    case green = "Green"
    case blue = "Blue"
    case violet = "Violet"
    case gray = "Gray"
    case white = "White"
    case gold = "Gold"
    case silver = "Silver"
    case none = "None"

    var id: String { rawValue }

    var digit: Int? {
        switch self {
        case .black: return 0
        case .brown: return 1
        case .red: return 2
        case .orange: return 3
        case .yellow: return 4
        case .green: return 5
        case .blue: return 6
        case .violet: return 7
        case .gray: return 8
        case .white: return 9
        default: return nil
        }
    }

    var multiplier: Double? {
        switch self {
        case .gold: return 0.1
        case .silver: return 0.01
        default:
            guard let digit else { return nil }
            return pow(10.0, Double(digit))
        }
    }

    var tolerance: Double? {
        switch self {
        case .brown: return 1
        case .red: return 2
        case .green: return 0.5
        case .blue: return 0.25
        case .violet: return 0.1
        case .gray: return 0.05
        case .gold: return 5
        case .silver: return 10
        case .none: return 20
        default: return nil
        }
    }

    var ppmPerKelvin: Int? {
        switch self {
        case .black: return 250
        case .brown: return 100
        case .red: return 50
        case .orange: return 15
        case .yellow: return 25
        case .green: return 20
        case .blue: return 10
        case .violet: return 5
        case .gray: return 1
        default: return nil
        }
    }
}

/// Context-specific choices prevent, for example, a gold *digit* or a red
/// tolerance being confused with its significance in another position.
enum BandRole: Equatable {
    case digit(Int)
    case multiplier
    case tolerance
    case temperature

    static func at(_ index: Int, total: Int) -> BandRole {
        let digits = total == 4 ? 2 : 3
        if index < digits { return .digit(index + 1) }
        if index == digits { return .multiplier }
        if index == digits + 1 { return .tolerance }
        return .temperature
    }

    var title: String {
        switch self {
        case .digit(let number): return "Digit \(number)"
        case .multiplier: return "Multiplier"
        case .tolerance: return "Tolerance"
        case .temperature: return "Temp. coefficient"
        }
    }

    var allowedColors: [BandColor] {
        BandColor.allCases.filter { color in
            if color == .unknown { return true }
            switch self {
            case .digit: return color.digit != nil
            case .multiplier: return color.multiplier != nil
            case .tolerance: return color.tolerance != nil
            case .temperature: return color.ppmPerKelvin != nil
            }
        }
    }

    func description(for color: BandColor) -> String {
        if color == .unknown { return "Choose color" }
        switch self {
        case .digit:
            return color.digit.map(String.init) ?? "Invalid"
        case .multiplier:
            switch color {
            case .silver: return "×0.01"
            case .gold: return "×0.1"
            case .black: return "×1"
            case .brown: return "×10"
            case .red: return "×100"
            case .orange: return "×1k"
            case .yellow: return "×10k"
            case .green: return "×100k"
            case .blue: return "×1M"
            case .violet: return "×10M"
            case .gray: return "×100M"
            case .white: return "×1G"
            default: return "Invalid"
            }
        case .tolerance:
            return color.tolerance.map { "±\(Self.number($0))%" } ?? "Invalid"
        case .temperature:
            return color.ppmPerKelvin.map { "\($0) ppm/K" } ?? "Invalid"
        }
    }

    func menuLabel(for color: BandColor) -> String {
        color == .unknown ? "Uncertain — choose color"
            : "\(color.rawValue) = \(description(for: color))"
    }

    private static func number(_ value: Double) -> String {
        value == floor(value) ? String(Int(value)) : String(value)
    }
}

struct ResistorReading: Equatable {
    let ohms: Double
    let tolerancePercent: Double
    let ppmPerKelvin: Int?

    var formattedResistance: String {
        let units: [(Double, String)] = [
            (1e9, "GΩ"), (1e6, "MΩ"), (1e3, "kΩ"), (1, "Ω")
        ]
        let selected = units.first { ohms >= $0.0 } ?? (1.0, "Ω")
        let scaled = ohms / selected.0
        return "\(Self.number(scaled)) \(selected.1)"
    }

    var formattedTolerance: String { "±\(Self.number(tolerancePercent))%" }

    var fullDescription: String {
        let base = "\(formattedResistance) \(formattedTolerance)"
        if let ppmPerKelvin { return "\(base), \(ppmPerKelvin) ppm/K" }
        return base
    }

    private static func number(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 4
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: value)) ?? String(value)
    }
}

enum ResistorDecoder {
    static func decode(_ bands: [BandColor]) -> ResistorReading? {
        guard (4...6).contains(bands.count) else { return nil }
        let digitCount = bands.count == 4 ? 2 : 3
        var number = 0
        for band in bands.prefix(digitCount) {
            guard let digit = band.digit else { return nil }
            number = (number * 10) + digit
        }
        // A leading black zero is not a standard significant-digit code.
        guard number >= (digitCount == 2 ? 10 : 100),
              let multiplier = bands[digitCount].multiplier,
              let tolerance = bands[digitCount + 1].tolerance else { return nil }
        let ppm = bands.count == 6 ? bands[5].ppmPerKelvin : nil
        if bands.count == 6 && ppm == nil { return nil }
        return ResistorReading(ohms: Double(number) * multiplier,
                               tolerancePercent: tolerance,
                               ppmPerKelvin: ppm)
    }
}
