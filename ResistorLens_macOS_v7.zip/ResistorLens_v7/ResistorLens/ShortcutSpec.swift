import Foundation

/// Physical-key shortcuts used with Carbon RegisterEventHotKey.
/// Keeping this model Foundation-only also makes the validation testable on Linux.
struct ShortcutSpec: Codable, Hashable {
    let keyCode: UInt32
    let modifierBits: UInt8

    static let shift: UInt8 = 1 << 0
    static let option: UInt8 = 1 << 1
    static let control: UInt8 = 1 << 2
    static let command: UInt8 = 1 << 3
    static let supportedFlags: UInt8 = shift | option | control | command
    static let `default` = ShortcutSpec(keyCode: 15, modifierBits: shift | option) // ⇧⌥R

    // US ANSI hardware key codes; the shortcut binds to the physical key.
    // Only ordinary letters and numbers are recorded to avoid modifier-only
    // shortcuts, media keys, and ambiguous macOS control/function keys.
    static let keyNames: [UInt32: String] = [
        0:"A", 11:"B", 8:"C", 2:"D", 14:"E", 3:"F", 5:"G", 4:"H",
        34:"I", 38:"J", 40:"K", 37:"L", 46:"M", 45:"N", 31:"O", 35:"P",
        12:"Q", 15:"R", 1:"S", 17:"T", 32:"U", 9:"V", 13:"W", 7:"X",
        16:"Y", 6:"Z", 18:"1", 19:"2", 20:"3", 21:"4", 23:"5",
        22:"6", 26:"7", 28:"8", 25:"9", 29:"0"
    ]

    var isValid: Bool {
        (modifierBits & ~Self.supportedFlags) == 0 &&
        modifierBits.nonzeroBitCount >= 2 && Self.keyNames[keyCode] != nil
    }

    var displayName: String {
        let symbols = [(Self.control,"⌃"), (Self.shift,"⇧"),
                       (Self.option,"⌥"), (Self.command,"⌘")]
        return symbols.filter { modifierBits & $0.0 != 0 }.map { $0.1 }.joined() +
               (Self.keyNames[keyCode] ?? "?")
    }
}
