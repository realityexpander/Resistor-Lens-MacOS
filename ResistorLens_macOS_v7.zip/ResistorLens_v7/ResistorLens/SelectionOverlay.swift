import AppKit

/// A transparent, mouse-intercepting layer. Draw from the *center* of the
/// first resistor band to the *center* of the last band, in reading order.
final class SelectionOverlay: NSView {
    var onSelection: ((NSPoint, NSPoint) -> Void)?
    var onCancel: (() -> Void)?
    private var start: NSPoint?
    private var end: NSPoint?

    override var acceptsFirstResponder: Bool { true }

    override func mouseDown(with event: NSEvent) {
        let point = convert(event.locationInWindow, from: nil)
        start = point
        end = point
        needsDisplay = true
    }

    override func mouseDragged(with event: NSEvent) {
        end = convert(event.locationInWindow, from: nil)
        needsDisplay = true
    }

    override func mouseUp(with event: NSEvent) {
        guard let start, let window else { return }
        let end = convert(event.locationInWindow, from: nil)
        let distance = hypot(end.x - start.x, end.y - start.y)
        if distance < 15 { NSSound.beep(); return }
        let screenStart = window.convertPoint(toScreen: start)
        let screenEnd = window.convertPoint(toScreen: end)
        onSelection?(screenStart, screenEnd)
    }

    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 { onCancel?() }
        else { super.keyDown(with: event) }
    }

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        NSColor.black.withAlphaComponent(0.10).setFill()
        NSBezierPath(rect: bounds).fill()

        let instructions = "Drag from the CENTER of band 1 to the CENTER of the last band • Esc cancels"
        let attrs: [NSAttributedString.Key: Any] = [
            .font: NSFont.boldSystemFont(ofSize: 16),
            .foregroundColor: NSColor.white,
            .backgroundColor: NSColor.black.withAlphaComponent(0.85)
        ]
        let title = NSAttributedString(string: "  \(instructions)  ", attributes: attrs)
        title.draw(at: NSPoint(x: max(12, bounds.midX - title.size().width / 2),
                               y: bounds.maxY - 54))

        guard let start, let end else { return }
        let line = NSBezierPath()
        line.move(to: start)
        line.line(to: end)
        line.lineWidth = 4
        NSColor.systemCyan.setStroke()
        line.stroke()
        for p in [start, end] {
            let dot = NSBezierPath(ovalIn: NSRect(x: p.x - 6, y: p.y - 6, width: 12, height: 12))
            NSColor.systemYellow.setFill()
            dot.fill()
        }
    }
}
