import AppKit

/// An auxiliary result/settings panel closes with Escape. While recording
/// a shortcut, the Settings view consumes the first Escape to cancel capture.
final class EscapeClosingPanel: NSPanel {
    override func cancelOperation(_ sender: Any?) {
        close()
    }

    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 {
            close()
        } else {
            super.keyDown(with: event)
        }
    }
}
