import AppKit
import ScreenCaptureKit

/// Captures the entire display containing the cursor, once, before showing an overlay.
/// No screenshots are written to disk or transmitted.
enum ScreenCapture {
    enum CaptureError: LocalizedError {
        case displayNotFound
        var errorDescription: String? { "Could not locate the display under the pointer." }
    }

    static func image(of screen: NSScreen) async throws -> CGImage {
        guard let screenNumber = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber else {
            throw CaptureError.displayNotFound
        }

        // Use the callback explicitly to work across supported macOS 14+ SDKs.
        let content: SCShareableContent = try await withCheckedThrowingContinuation { continuation in
            SCShareableContent.getExcludingDesktopWindows(false, onScreenWindowsOnly: true) { result, error in
                if let error { continuation.resume(throwing: error) }
                else if let result { continuation.resume(returning: result) }
                else { continuation.resume(throwing: CaptureError.displayNotFound) }
            }
        }
        guard let display = content.displays.first(where: { $0.displayID == screenNumber.uint32Value }) else {
            throw CaptureError.displayNotFound
        }
        let filter = SCContentFilter(display: display, excludingWindows: [])
        let config = SCStreamConfiguration()
        config.width = display.width
        config.height = display.height
        config.showsCursor = false
        config.scalesToFit = false
        return try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: config)
    }
}
