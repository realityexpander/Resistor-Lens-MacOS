import AppKit
import Carbon

/// RegisterEventHotKey works while other apps are foreground, without requiring
/// systemwide keystroke monitoring or Accessibility permission.
final class GlobalHotKey {
    private var activeRef: EventHotKeyRef?
    private var eventHandler: EventHandlerRef?
    private var activeShortcut: ShortcutSpec?
    private var nextIdentifier: UInt32 = 1
    private let action: () -> Void
    private(set) var registrationStatus: OSStatus = OSStatus(eventNotHandledErr)

    init(initialShortcut: ShortcutSpec, action: @escaping () -> Void) {
        self.action = action
        var eventType = EventTypeSpec(eventClass: OSType(kEventClassKeyboard),
                                      eventKind: UInt32(kEventHotKeyPressed))
        let handlerStatus = InstallEventHandler(GetApplicationEventTarget(), { _, _, userData in
            guard let userData else { return OSStatus(eventNotHandledErr) }
            let instance = Unmanaged<GlobalHotKey>.fromOpaque(userData).takeUnretainedValue()
            DispatchQueue.main.async { instance.action() }
            return noErr
        }, 1, &eventType, Unmanaged.passUnretained(self).toOpaque(), &eventHandler)

        if handlerStatus == noErr { registrationStatus = register(initialShortcut) }
        else { registrationStatus = handlerStatus }
    }

    /// Temporarily free the current combination while recording another one.
    /// The application restores the saved combination when recording ends.
    func suspend() {
        if let activeRef { UnregisterEventHotKey(activeRef) }
        activeRef = nil
        activeShortcut = nil
        registrationStatus = OSStatus(eventNotHandledErr)
    }

    @discardableResult
    func register(_ shortcut: ShortcutSpec) -> OSStatus {
        guard eventHandler != nil else { return registrationStatus }
        guard shortcut.isValid else { return OSStatus(paramErr) }
        if shortcut == activeShortcut && activeRef != nil { return noErr }
        let mask = (shortcut.modifierBits & ShortcutSpec.shift != 0 ? UInt32(shiftKey) : 0) |
                   (shortcut.modifierBits & ShortcutSpec.option != 0 ? UInt32(optionKey) : 0) |
                   (shortcut.modifierBits & ShortcutSpec.control != 0 ? UInt32(controlKey) : 0) |
                   (shortcut.modifierBits & ShortcutSpec.command != 0 ? UInt32(cmdKey) : 0)
        let identifier = EventHotKeyID(signature: 0x524C454E, id: nextIdentifier) // RLEN
        nextIdentifier &+= 1
        var proposedRef: EventHotKeyRef?
        let status = RegisterEventHotKey(shortcut.keyCode, mask, identifier,
                                         GetApplicationEventTarget(), 0, &proposedRef)
        // Register first: if a conflicting shortcut is rejected, the previous
        // working shortcut stays active rather than being lost.
        if status == noErr, let proposedRef {
            if let activeRef { UnregisterEventHotKey(activeRef) }
            activeRef = proposedRef
            activeShortcut = shortcut
            registrationStatus = noErr
        }
        return status
    }

    deinit {
        if let activeRef { UnregisterEventHotKey(activeRef) }
        if let eventHandler { RemoveEventHandler(eventHandler) }
    }
}
