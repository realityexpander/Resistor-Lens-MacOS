import AppKit

/// The percentage is an uncalibrated image-quality heuristic, NOT the
/// probability that the named color is correct.
struct BandEstimate {
    let color: BandColor
    let confidencePercent: Int
}

struct DetectionResult {
    let bands: [BandEstimate]
    let note: String
}

private struct RGB {
    let r: Double
    let g: Double
    let b: Double
    static func average(_ values: [RGB]) -> RGB {
        guard !values.isEmpty else { return RGB(r: 0, g: 0, b: 0) }
        return RGB(r: values.reduce(0) { $0 + $1.r } / Double(values.count),
                   g: values.reduce(0) { $0 + $1.g } / Double(values.count),
                   b: values.reduce(0) { $0 + $1.b } / Double(values.count))
    }
    var lab: Lab {
        func linear(_ x: Double) -> Double {
            let c = x / 255.0
            return c <= 0.04045 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4)
        }
        let r = linear(self.r), g = linear(self.g), b = linear(self.b)
        let x = (r * 0.4124564 + g * 0.3575761 + b * 0.1804375) / 0.95047
        let y = (r * 0.2126729 + g * 0.7151522 + b * 0.0721750)
        let z = (r * 0.0193339 + g * 0.1191920 + b * 0.9503041) / 1.08883
        func f(_ value: Double) -> Double {
            value > 0.008856 ? cbrt(value) : (7.787 * value + 16.0 / 116.0)
        }
        return Lab(l: 116 * f(y) - 16,
                   a: 500 * (f(x) - f(y)),
                   b: 200 * (f(y) - f(z)))
    }
}

private struct Lab {
    var l: Double, a: Double, b: Double
    func distance(to other: Lab) -> Double {
        sqrt(pow(l - other.l, 2) + pow(a - other.a, 2) + pow(b - other.b, 2))
    }
}

/// Converts a screenshot into a byte-addressable RGBA buffer. CoreGraphics bitmap
/// contexts have a bottom-left Cartesian origin, matching AppKit screen points.
private struct ImagePixels {
    let width: Int
    let height: Int
    let bytes: [UInt8]

    init?(image: CGImage) {
        let width = image.width, height = image.height
        guard width > 0, height > 0, width <= 16000, height <= 16000 else { return nil }
        self.width = width
        self.height = height
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        let rendered = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let address = buffer.baseAddress,
                  let context = CGContext(data: address,
                                          width: width, height: height,
                                          bitsPerComponent: 8,
                                          bytesPerRow: width * 4,
                                          space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue |
                                                      CGBitmapInfo.byteOrder32Big.rawValue) else {
                return false
            }
            context.interpolationQuality = .high
            context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard rendered else { return nil }
        self.bytes = pixels
    }

    func color(x: Int, y: Int) -> RGB {
        let cx = min(width - 1, max(0, x))
        let cy = min(height - 1, max(0, y))
        let offset = (cy * width + cx) * 4
        return RGB(r: Double(bytes[offset]),
                   g: Double(bytes[offset + 1]),
                   b: Double(bytes[offset + 2]))
    }
}

private struct BandRegion {
    let begin: Int
    let end: Int
    let color: BandColor
    let score: Double
    let confidencePercent: Int
}

/// Lightweight clustering, deliberately not advertised as a machine-vision certainty.
/// Real photos, reflective bands, low-resolution images and textured backgrounds
/// require manual review. Keep the independent human-editable band controls.
enum ColorBandDetector {
    static func detect(image: CGImage,
                       screenFrame: CGRect,
                       from start: CGPoint,
                       to end: CGPoint) -> DetectionResult {
        guard let pixels = ImagePixels(image: image) else {
            return DetectionResult(bands: [], note: "Image could not be read. Choose the colors manually.")
        }

        let length = hypot(end.x - start.x, end.y - start.y)
        guard length > 15 else {
            return DetectionResult(bands: [], note: "Draw a longer line across all the bands.")
        }
        let n = 360
        let xScale = Double(pixels.width) / Double(screenFrame.width)
        let yScale = Double(pixels.height) / Double(screenFrame.height)
        let dx = Double(end.x - start.x) * xScale
        let dy = Double(end.y - start.y) * yScale
        let magnitude = max(hypot(dx, dy), 1)
        let normalX = -dy / magnitude
        let normalY = dx / magnitude

        let samples: [RGB] = (0..<n).map { index in
            let t = Double(index) / Double(n - 1)
            let x = Double(start.x - screenFrame.minX) * xScale + dx * t
            let y = Double(start.y - screenFrame.minY) * yScale + dy * t
            // Sample a narrow strip around the line to reduce jagged-edge noise.
            return RGB.average((-2...2).map { offset in
                pixels.color(x: Int((x + Double(offset) * normalX).rounded()),
                             y: Int((y + Double(offset) * normalY).rounded()))
            })
        }

        let labs = samples.map(\.lab)
        let clusters = kMeans(labs, k: 7)
        guard !clusters.centers.isEmpty else {
            return DetectionResult(bands: [], note: "No color groups were found.")
        }
        let counts = clusters.centers.indices.map { id in clusters.labels.filter { $0 == id }.count }
        let background = counts.indices.max(by: { counts[$0] < counts[$1] }) ?? 0
        let baseLab = clusters.centers[background]

        // A tiny 5-sample majority filter removes isolated antialiased pixels.
        let labels: [Int] = clusters.labels.indices.map { i in
            let lower = max(0, i - 2), upper = min(n - 1, i + 2)
            let window = Array(clusters.labels[lower...upper])
            return clusters.centers.indices.max(by: { id0, id1 in
                window.filter { $0 == id0 }.count < window.filter { $0 == id1 }.count
            }) ?? clusters.labels[i]
        }

        var regions: [BandRegion] = []
        var cursor = 0
        while cursor < n {
            let group = labels[cursor]
            var next = cursor + 1
            while next < n && labels[next] == group { next += 1 }
            let size = next - cursor
            let contrast = clusters.centers[group].distance(to: baseLab)
            if group != background && size >= 4 && contrast >= 15 {
                // Use interior pixels so that transition antialiasing does not
                // skew the approximate color toward the resistor's body.
                let edge = min(3, size / 5)
                let region = Array(samples[(cursor + edge)..<(next - edge)])
                let classification = classify(region: region,
                                              contrast: contrast,
                                              size: size)
                if classification.color != .unknown {
                    regions.append(BandRegion(begin: cursor, end: next,
                                              color: classification.color,
                                              score: contrast * sqrt(Double(size)),
                                              confidencePercent: classification.confidence))
                }
            }
            cursor = next
        }

        // Join adjacent shades of the *same* band. Do not cross body gaps:
        // two separated bands are permitted to be the same color.
        var merged: [BandRegion] = []
        for band in regions {
            if let previous = merged.last,
               previous.end == band.begin && previous.color == band.color {
                merged[merged.count - 1] = BandRegion(begin: previous.begin, end: band.end,
                                                         color: band.color,
                                                         score: max(previous.score, band.score),
                                                         confidencePercent: Int((Double(previous.confidencePercent) + Double(band.confidencePercent)) / 2))
            } else {
                merged.append(band)
            }
        }

        // If there are many noisy candidates, keep the six strongest bands and
        // keep their left-to-right ordering. The result is still an *estimate*.
        if merged.count > 6 {
            merged = Array(merged.sorted(by: { $0.score > $1.score }).prefix(6))
                .sorted(by: { $0.begin < $1.begin })
        }
        let estimates = merged.map { BandEstimate(color: $0.color,
                                                   confidencePercent: $0.confidencePercent) }
        let message: String
        if (4...6).contains(estimates.count) {
            message = "Estimated \(estimates.count) bands. Verify every color, especially brown/red and gold/yellow."
        } else {
            message = "Detected \(estimates.count) candidate bands. Select 4, 5, or 6 bands and correct the colors."
        }
        return DetectionResult(bands: estimates, note: message)
    }

    private static func kMeans(_ samples: [Lab], k: Int) -> (centers: [Lab], labels: [Int]) {
        guard let first = samples.first else { return ([], []) }
        var centers: [Lab] = [first]
        while centers.count < min(k, samples.count) {
            let next = samples.max(by: { a, b in
                let da = centers.map { a.distance(to: $0) }.min() ?? 0
                let db = centers.map { b.distance(to: $0) }.min() ?? 0
                return da < db
            }) ?? first
            if (centers.map { next.distance(to: $0) }.min() ?? 0) < 4 { break }
            centers.append(next)
        }
        var labels = Array(repeating: 0, count: samples.count)
        for _ in 0..<12 {
            for (index, sample) in samples.enumerated() {
                labels[index] = centers.indices.min(by: {
                    sample.distance(to: centers[$0]) < sample.distance(to: centers[$1])
                }) ?? 0
            }
            for id in centers.indices {
                let group = samples.indices.filter { labels[$0] == id }
                guard !group.isEmpty else { continue }
                let inverse = 1.0 / Double(group.count)
                centers[id] = Lab(l: group.reduce(0.0) { $0 + samples[$1].l } * inverse,
                                  a: group.reduce(0.0) { $0 + samples[$1].a } * inverse,
                                  b: group.reduce(0.0) { $0 + samples[$1].b } * inverse)
            }
        }
        return (centers, labels)
    }

    // Representative sRGB swatches, not calibrated real-world pigment samples.
    private static let references: [(BandColor, RGB)] = [
        (.black, RGB(r: 23, g: 23, b: 23)),
        (.brown, RGB(r: 105, g: 54, b: 26)),
        (.red, RGB(r: 210, g: 35, b: 38)),
        (.orange, RGB(r: 244, g: 112, b: 18)),
        (.yellow, RGB(r: 245, g: 210, b: 39)),
        (.green, RGB(r: 30, g: 141, b: 59)),
        (.blue, RGB(r: 29, g: 77, b: 202)),
        (.violet, RGB(r: 140, g: 61, b: 182)),
        (.gray, RGB(r: 129, g: 129, b: 129)),
        (.white, RGB(r: 242, g: 242, b: 242)),
        (.gold, RGB(r: 199, g: 154, b: 50)),
        (.silver, RGB(r: 189, g: 191, b: 196))
    ]

    private static func nearest(to sample: Lab) -> (color: BandColor, distance: Double, second: Double) {
        let matches = references.map { ($0.0, sample.distance(to: $0.1.lab)) }
            .sorted { $0.1 < $1.1 }
        guard let best = matches.first else { return (.unknown, 100, 100) }
        return (best.0, best.1, matches.dropFirst().first?.1 ?? best.1)
    }

    private static func classify(region: [RGB], contrast: Double,
                                 size: Int) -> (color: BandColor, confidence: Int) {
        guard !region.isEmpty else { return (.unknown, 0) }
        let mean = RGB.average(region).lab
        let best = nearest(to: mean)
        // Three interpretable heuristics: closeness to a reference color,
        // separation from runner-up colors, and within-band consistency.
        // This is deliberately not a calibrated probability model.
        let fit = min(1.0, max(0.0, (65.0 - best.distance) / 55.0))
        let separation = min(1.0, max(0.0, (best.second - best.distance) / 35.0))
        let agreement = Double(region.filter { nearest(to: $0.lab).color == best.color }.count)
                      / Double(region.count)
        let contrastQuality = min(1.0, max(0.0, (contrast - 15.0) / 45.0))
        let widthQuality = min(1.0, max(0.0, Double(size) / 14.0))
        let percentage = 15.0 + 40.0 * fit + 23.0 * separation + 12.0 * agreement
                       + 6.0 * contrastQuality + 4.0 * widthQuality
        return (best.color, min(98, max(10, Int(percentage.rounded()))))
    }
}
