import AppKit
import CoreGraphics

/// Only this small selected region is retained by the result window. The full
/// screenshot is never saved to disk or kept alive after detection completes.
struct CapturedResistorCrop {
    let image: CGImage
    /// Fractions of the output width, after rotation, of the user-drawn line.
    let scanStartX: CGFloat
    let scanEndX: CGFloat
}

/// Produces a *real pixel crop* of the captured screen, with the selected
/// resistor axis rotated to horizontal. This is not the generated illustration.
///
/// AppKit screen coordinates have a bottom-left origin. The screenshot is
/// drawn into a CoreGraphics bitmap context with the same y-up orientation.
/// Both the band detector and this renderer therefore use identical
/// point-to-pixel scaling (including non-1x Retina displays).
enum ResistorCrop {
    static func make(image: CGImage, screenFrame: CGRect,
                     from start: CGPoint, to end: CGPoint) -> CapturedResistorCrop? {
        guard let geometry = CropGeometry.calculate(
            imagePixelSize: CGSize(width: image.width, height: image.height),
            screenFrame: screenFrame, from: start, to: end) else { return nil }

        guard let context = CGContext(data: nil,
                                      width: geometry.outputWidth,
                                      height: geometry.outputHeight,
                                      bitsPerComponent: 8, bytesPerRow: 0,
                                      space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            return nil
        }
        // Neutral background identifies blank areas beyond the display edge.
        context.setFillColor(NSColor.windowBackgroundColor.cgColor)
        context.fill(CGRect(x: 0, y: 0,
                            width: geometry.outputWidth, height: geometry.outputHeight))
        context.interpolationQuality = .high
        context.translateBy(x: CGFloat(geometry.outputWidth) / 2,
                            y: CGFloat(geometry.outputHeight) / 2)
        context.scaleBy(x: geometry.outputScale, y: geometry.outputScale)
        context.rotate(by: -geometry.rotationRadians)
        context.translateBy(x: -geometry.midpointInPixels.x,
                            y: -geometry.midpointInPixels.y)
        context.draw(image, in: CGRect(x: 0, y: 0,
                                       width: image.width, height: image.height))
        guard let croppedImage = context.makeImage() else { return nil }
        return CapturedResistorCrop(image: croppedImage,
                                   scanStartX: geometry.scanStartX,
                                   scanEndX: geometry.scanEndX)
    }
}
