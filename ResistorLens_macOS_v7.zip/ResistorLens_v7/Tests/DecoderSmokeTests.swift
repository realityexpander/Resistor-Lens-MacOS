import Foundation

@main
struct DecoderSmokeTests {
    static func main() {
        let samples: [([BandColor], Double, Double, Int?)] = [
            ([.yellow, .violet, .red, .gold], 4700, 5, nil),
            ([.brown, .black, .red, .gold], 1000, 5, nil),
            ([.brown, .black, .black, .brown, .brown], 1000, 1, nil),
            ([.red, .violet, .orange, .black, .brown], 273, 1, nil),
            ([.red, .violet, .orange, .black, .brown, .red], 273, 1, 50),
            ([.brown, .black, .gold, .silver], 1, 10, nil),
            ([.yellow, .violet, .gold, .none], 4.7, 20, nil),
            ([.brown, .black, .silver, .gold], 0.1, 5, nil)
        ]
        for (bands, resistance, tolerance, ppm) in samples {
            guard let result = ResistorDecoder.decode(bands) else {
                fatalError("Failed to decode \(bands)")
            }
            assert(abs(result.ohms - resistance) < 0.00001)
            assert(result.tolerancePercent == tolerance)
            assert(result.ppmPerKelvin == ppm)
            print("PASS \(bands.map(\.rawValue).joined(separator: "–")): \(result.fullDescription)")
        }

        // Check what the menus actually say at each band position.
        assert(BandRole.at(0, total: 4) == .digit(1))
        assert(BandRole.at(1, total: 4) == .digit(2))
        assert(BandRole.at(2, total: 4) == .multiplier)
        assert(BandRole.at(3, total: 4) == .tolerance)
        assert(BandRole.at(3, total: 5) == .multiplier)
        assert(BandRole.at(4, total: 6) == .tolerance)
        assert(BandRole.at(5, total: 6) == .temperature)
        assert(BandRole.digit(1).menuLabel(for: .black) == "Black = 0")
        assert(BandRole.multiplier.menuLabel(for: .red) == "Red = ×100")
        assert(BandRole.tolerance.menuLabel(for: .gold) == "Gold = ±5%")
        assert(BandRole.temperature.menuLabel(for: .brown) == "Brown = 100 ppm/K")
        assert(BandRole.tolerance.menuLabel(for: .none) == "None = ±20%")
        assert(BandRole.digit(1).allowedColors.contains(.black))
        assert(!BandRole.digit(1).allowedColors.contains(.gold))
        assert(!BandRole.tolerance.allowedColors.contains(.white))
        assert(!BandRole.multiplier.allowedColors.contains(.none))
        print("PASS position-specific menus")

        // A manual edit changes the computed value immediately when the UI re-renders.
        var colors: [BandColor] = [.yellow, .violet, .red, .gold]
        assert(ResistorDecoder.decode(colors)?.ohms == 4700)
        colors[2] = .brown
        assert(ResistorDecoder.decode(colors)?.ohms == 470)
        colors[3] = .silver
        assert(ResistorDecoder.decode(colors)?.tolerancePercent == 10)
        print("PASS live recalculation via edited decoder input")

        assert(ResistorDecoder.decode([.unknown, .violet, .red, .gold]) == nil)
        assert(ResistorDecoder.decode([.black, .violet, .red, .gold]) == nil)
        assert(ResistorDecoder.decode([.yellow, .gold, .red, .gold]) == nil)
        assert(ResistorDecoder.decode([.yellow, .violet, .red, .white]) == nil)
        print("PASS invalid/uncertain band checks")
    }
}
