import Foundation

@main
struct ShortcutSmokeTests {
    static func main() {
        let initial = ShortcutSpec.default
        assert(initial.isValid)
        assert(initial.displayName == "⇧⌥R")
        assert(ShortcutSpec(keyCode: 15, modifierBits: ShortcutSpec.command | ShortcutSpec.option).displayName == "⌥⌘R")
        assert(ShortcutSpec(keyCode: 18, modifierBits: ShortcutSpec.control | ShortcutSpec.shift).displayName == "⌃⇧1")
        assert(!ShortcutSpec(keyCode: 15, modifierBits: ShortcutSpec.command).isValid)
        assert(!ShortcutSpec(keyCode: 53, modifierBits: ShortcutSpec.command | ShortcutSpec.option).isValid)
        assert(!ShortcutSpec(keyCode: 15, modifierBits: 255).isValid)
        for key in ShortcutSpec.keyNames.keys {
            let shortcut = ShortcutSpec(keyCode: key, modifierBits: ShortcutSpec.shift | ShortcutSpec.option)
            assert(shortcut.isValid, "Rejected key code \(key)")
            let bytes = try! JSONEncoder().encode(shortcut)
            assert(try! JSONDecoder().decode(ShortcutSpec.self, from: bytes) == shortcut)
        }
        print("PASS shortcut validation, display labels, default, and persistent-value serialization")
    }
}
