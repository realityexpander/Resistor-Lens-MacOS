import Foundation

struct ScanCorpus: Decodable {
    let schemaVersion: Int
    let datasetType: String
    let warning: String?
    let cases: [ScanCase]
}

struct ScanCase: Decodable {
    let id: String
    let kind: String
    let source: String
    let bands: [BandColor]
    let expectedOhms: Double
    let expectedTolerancePercent: Double
    let expectedPPM: Int?
    let rgbScan: [[Int]]
    let style: String?
    let body: String?
}

enum ScanCorpusLoader {
    static func read(path: String) throws -> ScanCorpus {
        let url = URL(fileURLWithPath: path)
        let corpus = try JSONDecoder().decode(ScanCorpus.self, from: Data(contentsOf: url))
        guard corpus.schemaVersion == 1 else {
            throw Failure.invalid("Unrecognized schemaVersion \(corpus.schemaVersion)")
        }
        var ids = Set<String>()
        for test in corpus.cases {
            guard ids.insert(test.id).inserted else { throw Failure.invalid("Duplicate ID: \(test.id)") }
            guard (4...6).contains(test.bands.count) else { throw Failure.invalid("Bad band count in \(test.id)") }
            guard test.bands.allSatisfy({ $0 != .unknown && $0 != .none }) else {
                throw Failure.invalid("Non-pigment band in \(test.id)")
            }
            guard test.rgbScan.count == 360,
                  test.rgbScan.allSatisfy({ $0.count == 3 && $0.allSatisfy({ (0...255).contains($0) }) }) else {
                throw Failure.invalid("Wrong sample count / RGB in \(test.id)")
            }
            guard let decoded = ResistorDecoder.decode(test.bands),
                  abs(decoded.ohms - test.expectedOhms) <= max(0.000001, test.expectedOhms * 1e-9),
                  abs(decoded.tolerancePercent - test.expectedTolerancePercent) < 1e-9,
                  decoded.ppmPerKelvin == test.expectedPPM else {
                throw Failure.invalid("Incorrect ground-truth band decoding in \(test.id)")
            }
        }
        return corpus
    }

    enum Failure: Error, CustomStringConvertible {
        case invalid(String)
        var description: String {
            if case let .invalid(detail) = self { return detail }
            return "Unknown corpus error"
        }
    }
}
