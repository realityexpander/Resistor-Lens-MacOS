#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo '=== Decoder ==='
swiftc ResistorLens/ResistorCode.swift Tests/DecoderSmokeTests.swift -o "$WORK/decoder"
"$WORK/decoder"
echo '=== Crop geometry ==='
swiftc ResistorLens/CropGeometry.swift Tests/CropGeometrySmokeTests.swift -o "$WORK/geometry"
"$WORK/geometry"
echo '=== Shortcut ==='
swiftc ResistorLens/ShortcutSpec.swift Tests/ShortcutSmokeTests.swift -o "$WORK/shortcut"
"$WORK/shortcut"
echo '=== Low confidence banner rules ==='
swiftc ResistorLens/ConfidenceWarning.swift Tests/ConfidenceWarningTests.swift -o "$WORK/confidence-warning"
"$WORK/confidence-warning"
echo '=== 50 synthetic cases / RGB coverage / confidence-audit math ==='
swiftc ResistorLens/ResistorCode.swift Tests/CorpusFormat.swift Tests/ConfidenceAudit.swift \
  Tests/CorpusIntegrityTests.swift -o "$WORK/corpus"
"$WORK/corpus" Fixtures/synthetic_scans_50.json

if [ "$(uname -s)" = 'Darwin' ]; then
  echo '=== Production ColorBandDetector on 50 synthetic RGB scan images ==='
  swiftc -framework AppKit ResistorLens/ResistorCode.swift ResistorLens/ColorBandDetector.swift \
    Tests/CorpusFormat.swift Tests/ConfidenceAudit.swift Tests/DetectorCorpusTests.swift \
    -o "$WORK/audit"
  "$WORK/audit" Fixtures/synthetic_scans_50.json "${PWD}/synthetic_detector_report.csv"
  if [ -f Fixtures/real_scans_50.json ]; then
    echo '=== Production ColorBandDetector on 50 real-photo RGB scans ==='
    "$WORK/audit" Fixtures/real_scans_50.json "${PWD}/real_photo_detector_report.csv"
  else
    echo 'SKIP real-image audit: download Roboflow YOLO dataset and run Tools/import_roboflow_yolo.py first'
  fi
else
  echo 'SKIP production image detector: AppKit only exists on macOS; no detection accuracy claimed.'
fi
