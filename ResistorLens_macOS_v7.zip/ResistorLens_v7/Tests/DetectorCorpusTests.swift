// macOS-only black-box regression/audit runner. Uses *unchanged* ColorBandDetector.
// Run from project root; see README. The scan profiles are real RGB values (or
// explicitly labeled synthetic RGB values), reconstructed as a flat image to
// exercise the same production code path without distributing source photos.
import AppKit
import Foundation

@main
struct DetectorCorpusTests {
    static func scanAsImage(_ pixels: [[Int]]) -> CGImage? {
        let width = 360, height = 24
        guard pixels.count == width else { return nil }
        var bytes = [UInt8]()
        bytes.reserveCapacity(width * height * 4)
        for _ in 0..<height {
            for p in pixels {
                bytes.append(UInt8(p[0]))
                bytes.append(UInt8(p[1]))
                bytes.append(UInt8(p[2]))
                bytes.append(255)
            }
        }
        let data = Data(bytes)
        guard let provider = CGDataProvider(data: data as CFData) else { return nil }
        return CGImage(width: width, height: height,
                       bitsPerComponent: 8, bitsPerPixel: 32,
                       bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue |
                                  CGBitmapInfo.byteOrder32Big.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: false,
                       intent: .defaultIntent)
    }

    static func main() throws {
        let args = CommandLine.arguments
        guard args.count >= 2 else {
            print("Usage: ./resistor-detector-audit Fixtures/synthetic_scans_50.json [optional-report.csv]")
            exit(2)
        }
        let corpus = try ScanCorpusLoader.read(path: args[1])
        var audit = ConfidenceAudit()
        var csv = ["id,sourceType,expected,detected,confidenceScores,exactReading"]
        for fixture in corpus.cases {
            guard let image = scanAsImage(fixture.rgbScan) else {
                fatalError("Cannot reconstruct RGB scan: \(fixture.id)")
            }
            let detected = ColorBandDetector.detect(image: image,
                      screenFrame: CGRect(x: 0, y: 0, width: 360, height: 24),
                      from: CGPoint(x: 0, y: 12), to: CGPoint(x: 359, y: 12))
            for band in detected.bands {
                guard (10...98).contains(band.confidencePercent) else {
                    fatalError("Detector returned out-of-range confidence for \(fixture.id)")
                }
            }
            let predictions = detected.bands.map {
                AuditDetection(color: $0.color, confidencePercent: $0.confidencePercent)
            }
            audit.add(expected: fixture.bands, detected: predictions)
            let exact = fixture.bands.count == predictions.count &&
                zip(fixture.bands, predictions).allSatisfy { $0 == $1.color }
            let row = [fixture.id, fixture.kind,
                       fixture.bands.map(\.rawValue).joined(separator: " "),
                       predictions.map { $0.color.rawValue }.joined(separator:" "),
                       predictions.map { String($0.confidencePercent) }.joined(separator:" "),
                       String(exact)]
            csv.append(row.map { "\"\($0.replacingOccurrences(of: "\"", with: "\"\""))\"" }.joined(separator:","))
        }
        print(audit.report(corpusName: corpus.datasetType))
        if args.count >= 3 {
            try (csv.joined(separator:"\n") + "\n").write(toFile:args[2], atomically:true, encoding:.utf8)
            print("Wrote per-case predictions to \(args[2])")
        }
        if corpus.datasetType.lowercased().contains("synthetic") {
            print("NOTE: synthetic-only results cannot establish real-photo recognition accuracy.")
        }
    }
}
