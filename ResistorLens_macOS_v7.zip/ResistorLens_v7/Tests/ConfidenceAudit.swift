import Foundation

/// A measured observation, reported ONLY after running the detector against an
/// image-derived scan with a human/source-supplied ground-truth color. The
/// detector's percentages are uncalibrated and are NOT probabilities.
struct ConfidenceObservation {
    let bandColor: BandColor
    let predictedColor: BandColor
    let score: Int
    var correct: Bool { bandColor == predictedColor }
}

struct AuditDetection {
    let color: BandColor
    let confidencePercent: Int
}

struct ConfidenceAudit {
    var observations: [ConfidenceObservation] = []
    var missingBands = 0
    var unexpectedBands = 0
    var exactScans = 0
    var totalScans = 0

    private let buckets: [(String, ClosedRange<Int>)] = [
        ("10–49",10...49),("50–74",50...74),
        ("75–89",75...89),("90–98",90...98)
    ]

    mutating func add(expected: [BandColor], detected: [AuditDetection]) {
        totalScans += 1
        let exact = expected.count == detected.count &&
                    zip(expected, detected).allSatisfy { $0 == $1.color }
        if exact { exactScans += 1 }
        missingBands += max(0, expected.count - detected.count)
        unexpectedBands += max(0, detected.count - expected.count)
        for index in 0..<min(expected.count, detected.count) {
            observations.append(ConfidenceObservation(bandColor: expected[index],
                                                       predictedColor: detected[index].color,
                                                       score: detected[index].confidencePercent))
        }
    }

    func report(corpusName: String) -> String {
        let matches = observations.filter(\.correct).count
        var lines = ["Corpus: \(corpusName)",
                     "Exact full scans: \(exactScans)/\(totalScans)",
                     "Position-matched bands: \(matches)/\(observations.count)",
                     "Missing expected bands: \(missingBands); extra detected bands: \(unexpectedBands)",
                     "Confidence bucket | Correct/Total | Empirical accuracy | Mean reported score"]
        for (name, range) in buckets {
            let values = observations.filter { range.contains($0.score) }
            let correct = values.filter(\.correct).count
            let accuracy = values.isEmpty ? "n/a" : String(format:"%.1f%%",Double(correct)*100/Double(values.count))
            let mean = values.isEmpty ? "n/a" : String(format:"%.1f%%",Double(values.reduce(0){$0+$1.score})/Double(values.count))
            lines.append("\(name) | \(correct)/\(values.count) | \(accuracy) | \(mean)")
        }
        lines.append("Accuracy by expected pigment (includes only matched band positions):")
        for color in BandColor.allCases where color.digit != nil || color == .gold || color == .silver {
            let values = observations.filter { $0.bandColor == color }
            if !values.isEmpty {
                lines.append("  \(color.rawValue): \(values.filter(\.correct).count)/\(values.count)")
            }
        }
        lines.append("DISCLAIMER: Buckets describe observed accuracy in THIS test corpus, not calibrated probability and not general performance.")
        return lines.joined(separator:"\n")
    }
}
