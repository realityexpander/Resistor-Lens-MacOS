import Foundation

@main
struct CorpusIntegrityTests {
    static func main() throws {
        let path = CommandLine.arguments.dropFirst().first ?? "Fixtures/synthetic_scans_50.json"
        let corpus = try ScanCorpusLoader.read(path: path)
        guard corpus.cases.count == 50 else { fatalError("Expected 50 cases, found \(corpus.cases.count)") }
        guard Set(corpus.cases.map(\.kind)) == ["synthetic"] else {
            fatalError("This test must not confuse real and synthetic data")
        }
        let palette = Set(corpus.cases.flatMap(\.bands))
        let expectedPalette = Set(BandColor.allCases.filter { $0.digit != nil || $0 == .gold || $0 == .silver })
        guard palette == expectedPalette else { fatalError("Not all 12 pigments represented") }
        for size in 4...6 {
            guard corpus.cases.filter({ $0.bands.count == size }).count >= 10 else {
                fatalError("Insufficient \(size)-band coverage")
            }
        }
        let styles = Set(corpus.cases.compactMap(\.style))
        guard styles.count >= 8 else { fatalError("Insufficient lighting/color variations") }
        // Exercise audit bucket logic with *invented* observations, NOT model outcomes.
        // This only tests accounting/math: it must not be presented as actual detector accuracy.
        var audit = ConfidenceAudit()
        let fakeScores = [14, 42, 58, 73, 75, 89, 90, 98]
        let fakeColors: [BandColor] = [.brown,.red,.orange,.yellow,.green,.blue,.violet,.gold]
        for (i, score) in fakeScores.enumerated() {
            let predicted = i.isMultiple(of: 2) ? fakeColors[i] : .black
            audit.observations.append(ConfidenceObservation(bandColor: fakeColors[i],
                                                           predictedColor: predicted, score: score))
        }
        guard audit.observations.filter(\.correct).count == 4 else { fatalError("Broken audit math") }
        print("PASS 50 deterministic synthetic scans, 12 pigments, 4/5/6 bands, \(styles.count) image conditions")
        print("PASS independently stored expected values, tolerances, temperature coefficients")
        print("PASS confidence audit bucket/accounting unit tests (synthetic observations only)")
        print("NOT RUN: actual AppKit detector (requires macOS; run DetectorCorpusTests.swift there)")
    }
}
