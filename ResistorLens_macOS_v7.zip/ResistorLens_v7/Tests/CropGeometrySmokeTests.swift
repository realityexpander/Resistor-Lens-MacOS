import Foundation

@main
struct CropGeometrySmokeTests {
    static func main() {
        let screen = CGRect(x: 100, y: 200, width: 1000, height: 500)
        let imageSize = CGSize(width: 2000, height: 1000) // 2x Retina

        guard let horizontal = CropGeometry.calculate(imagePixelSize: imageSize,
                                                       screenFrame: screen,
                                                       from: CGPoint(x: 200, y: 300),
                                                       to: CGPoint(x: 400, y: 300)) else {
            fatalError("Failed horizontal geometry")
        }
        assert(horizontal.midpointInPixels == CGPoint(x: 400, y: 200))
        assert(horizontal.outputWidth == 600 && horizontal.outputHeight == 220)
        assert(abs(horizontal.rotationRadians) < 0.00001)
        assert(abs(horizontal.scanStartX - 1.0 / 6.0) < 0.001)
        assert(abs(horizontal.scanEndX - 5.0 / 6.0) < 0.001)
        print("PASS horizontal, Retina, nonzero display origin")

        guard let vertical = CropGeometry.calculate(imagePixelSize: imageSize,
                                                     screenFrame: screen,
                                                     from: CGPoint(x: 200, y: 300),
                                                     to: CGPoint(x: 200, y: 400)) else {
            fatalError("Failed vertical geometry")
        }
        assert(abs(vertical.rotationRadians - .pi / 2) < 0.00001)
        assert(vertical.outputWidth == 300 && vertical.outputHeight == 110)
        print("PASS vertical selection rotation")

        let reverse = CropGeometry.calculate(imagePixelSize: imageSize,
                                              screenFrame: screen,
                                              from: CGPoint(x: 400, y: 300),
                                              to: CGPoint(x: 200, y: 300))!
        assert(abs(abs(reverse.rotationRadians) - .pi) < 0.00001)
        assert(reverse.scanStartX == horizontal.scanStartX)
        assert(reverse.scanEndX == horizontal.scanEndX)
        print("PASS reverse direction")

        let large = CropGeometry.calculate(imagePixelSize: CGSize(width: 7000, height: 3500),
                                            screenFrame: screen,
                                            from: CGPoint(x: 200, y: 300),
                                            to: CGPoint(x: 980, y: 320))!
        assert(large.outputWidth <= 1100 && large.outputHeight <= 460)
        assert(large.scanStartX > 0 && large.scanEndX < 1)
        print("PASS bounded crop resolution")

        assert(CropGeometry.calculate(imagePixelSize: imageSize, screenFrame: screen,
                                      from: .zero, to: .zero) == nil)
        assert(CropGeometry.calculate(imagePixelSize: .zero, screenFrame: screen,
                                      from: .zero, to: CGPoint(x: 500, y: 500)) == nil)
        print("PASS invalid inputs")
    }
}
