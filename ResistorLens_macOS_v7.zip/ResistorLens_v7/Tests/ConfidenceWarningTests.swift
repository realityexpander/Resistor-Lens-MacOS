import Foundation

@main
struct ConfidenceWarningTests {
    static func evaluate(_ scores: [Int?], edits: Set<Int> = [],
                         average: Int = 60, critical: Int = 25) -> ConfidenceWarningAssessment {
        ConfidenceWarningAssessment.evaluate(scores.enumerated().map { index, value in
            ConfidenceWarningInput(confidencePercent: value, manuallyEdited: edits.contains(index))
        }, averageThreshold: average, criticalThreshold: critical)
    }

    static func main() {
        func check(_ condition: @autoclosure () -> Bool, _ description: String) {
            guard condition() else { fatalError("FAIL: \(description)") }
        }
        let good = evaluate([89, 78, 96, 65])
        check(!good.shouldWarn, "normal bands should not raise banner")
        check(good.averagePercent == 82, "mean of 4 scores")
        check(good.evaluatedCount == 4, "all 4 scores included")

        let lowMean = evaluate([59, 58, 57, 59])
        check(lowMean.shouldWarn && lowMean.averageBelowThreshold, "mean below 60 alerts")
        check(lowMean.criticalBands.isEmpty, "no false critical flags")
        check(lowMean.details.contains("Average 58.2%"), "one-decimal average shown")

        let individual = evaluate([93, 92, 24, 90])
        check(individual.shouldWarn && !individual.averageBelowThreshold, "single band below 25 alerts")
        check(individual.criticalBands.count == 1 && individual.criticalBands[0].number == 3,
              "alert names specific band")
        check(individual.details.contains("Band 3: 24%"), "critical score exposed")

        let both = evaluate([10, 42, 61, 70, 81])
        check(both.averageBelowThreshold && both.criticalBands.count == 1, "combined thresholds")

        let averageBoundary = evaluate([60, 60, 60, 60])
        check(!averageBoundary.shouldWarn, "60 is not below 60")
        let criticalBoundary = evaluate([25, 100, 100, 100])
        check(!criticalBoundary.shouldWarn, "25 is not below 25 and average is over 60")

        let missing = evaluate([90, nil, 88, 87])
        check(missing.shouldWarn && missing.missingBandNumbers == [2], "missing scan is warning")
        check(missing.averagePercent != nil && missing.evaluatedCount == 3, "missing band not turned into 0 score")
        let allMissing = evaluate([nil, nil, nil, nil])
        check(allMissing.shouldWarn && allMissing.averagePercent == nil, "no evidence alerts without fake 0 mean")

        let edited = evaluate([15, 94, 95, 95], edits: [0])
        check(!edited.shouldWarn, "manually corrected band excluded from unresolved risk")
        check(edited.manualCount == 1 && edited.evaluatedCount == 3, "manual edits not assigned 100%")
        let allManual = evaluate([nil, nil, nil, nil], edits: [0, 1, 2, 3])
        check(!allManual.shouldWarn && allManual.averagePercent == nil,
              "all manual overrides have no artificial detector score")
        let editedStillMissing = evaluate([nil, nil, 88, 88], edits: [0])
        check(editedStillMissing.missingBandNumbers == [2], "other missing bands still alert")

        let customizable = evaluate([54, 55, 56, 55], average: 55, critical: 20)
        check(!customizable.shouldWarn, "settings thresholds take effect")
        let raised = evaluate([54, 55, 56, 55], average: 60, critical: 20)
        check(raised.shouldWarn, "raising average limit alerts")
        let expanded = evaluate([92, 92, 30, 90], average: 60, critical: 35)
        check(expanded.shouldWarn && expanded.criticalBands[0].number == 3, "custom single-band limit")

        for size in 4...6 {
            let clean = evaluate(Array(repeating: 95, count: size))
            check(!clean.shouldWarn && clean.evaluatedCount == size, "band count \(size)")
        }
        let clamped = evaluate([101, -4, 95, 96])
        check(clamped.criticalBands.first?.percent == 0, "out-of-range detector scores clamped")
        print("PASS confidence warning: mean <60%, any band <25%, missing readings, boundaries")
        print("PASS 4/5/6 bands, manual corrections, live threshold changes, visible reasons")
        print("PASS independent of production scanner and statistically uncalibrated scores")
    }
}
